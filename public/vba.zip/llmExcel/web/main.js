const runtimeStatusEl = document.getElementById("runtimeStatus");
const modelStatusEl = document.getElementById("modelStatus");
const promptInputEl = document.getElementById("promptInput");
const runBtn = document.getElementById("runBtn");
const responseEl = document.getElementById("response");

const state = {
  config: null,
  runtimeModule: null,
  runtimeModulePromise: null,
  wllama: null,
  model: null,
  modelLoadPromise: null,
  inferenceInFlight: false,
  queuePollInFlight: false,
  queuePollTimer: null,
  currentJobId: null,
  bootstrapComplete: false,
  runtimeNotice: "",
  runtimeNoticeIsError: false,
  webGpuInfo: {
    available: false,
    label: "not checked",
  },
};

function setStatus(element, message, isError = false, isOk = false) {
  if (!element) {
    return;
  }

  element.textContent = message;
  element.classList.toggle("error", isError);
  element.classList.toggle("ok", isOk && !isError);
}

function getErrorMessage(error) {
  if (error instanceof Error) {
    return error.message;
  }

  return String(error);
}

function resolveHostBridge() {
  try {
    return globalThis.chrome?.webview?.hostObjects?.sync?.LLMExcelHost ?? null;
  } catch (_error) {
    return null;
  }
}

function callHost(methodName, ...args) {
  const hostBridge = resolveHostBridge();
  if (!hostBridge) {
    return false;
  }

  try {
    hostBridge[methodName](...args);
    return true;
  } catch (error) {
    console.warn(`[LLMExcel host] ${methodName} failed`, error);
    return false;
  }
}

function getQueuePollIntervalMs() {
  const configured = Number(state.config?.queuePollIntervalMs || 750);
  return Math.max(250, configured);
}

function buildRuntimeStatusLines() {
  const lines = [
    `runtime: ${state.config?.runtimeKind || "wllama-wasm"}`,
    `WebGPU: ${state.webGpuInfo.label}`,
    `crossOriginIsolated: ${window.crossOriginIsolated ? "yes" : "no"}`,
    `model: ${state.config?.modelFileName || "(not loaded)"}`,
    `queue: ${state.inferenceInFlight ? `busy (${state.currentJobId || "unknown"})` : "idle"}`,
  ];

  if (state.runtimeNotice) {
    lines.push(state.runtimeNotice);
  }

  return lines;
}

function renderRuntimeStatus() {
  setStatus(
    runtimeStatusEl,
    buildRuntimeStatusLines().join("\n"),
    state.runtimeNoticeIsError,
    state.bootstrapComplete && !state.runtimeNoticeIsError
  );
}

function clearRuntimeNotice() {
  state.runtimeNotice = "";
  state.runtimeNoticeIsError = false;
}

function setRuntimeNotice(message, isError = false) {
  state.runtimeNotice = message;
  state.runtimeNoticeIsError = isError;
  renderRuntimeStatus();
}

function getBridgeStatus() {
  return {
    runtimeKind: state.config?.runtimeKind || "wllama-wasm",
    modelFileName: state.model?.fileName || state.config?.modelFileName || null,
    modelLoaded: Boolean(state.model),
    webGpuAvailable: state.webGpuInfo.available,
    webGpuLabel: state.webGpuInfo.label,
    crossOriginIsolated: window.crossOriginIsolated,
    inferenceBusy: state.inferenceInFlight,
    currentJobId: state.currentJobId,
  };
}

function publishBridgeStatus({ ready = false } = {}) {
  const statusJson = JSON.stringify(getBridgeStatus());
  callHost("BridgeStatus", statusJson);
  if (ready) {
    callHost("BridgeReady", statusJson);
  }
}

async function probeWebGpu() {
  if (!navigator.gpu) {
    return {
      available: false,
      label: "navigator.gpu is unavailable",
    };
  }

  try {
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) {
      return {
        available: false,
        label: "WebGPU adapter not found",
      };
    }

    return {
      available: true,
      label: `adapter available (${adapter.features.size} features)`,
    };
  } catch (error) {
    return {
      available: false,
      label: `probe failed: ${getErrorMessage(error)}`,
    };
  }
}

async function fetchBridgeConfig() {
  const response = await fetch("/bridge/config", {
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`bridge config request failed (${response.status})`);
  }

  return response.json();
}

async function ensureRuntimeModule() {
  if (state.runtimeModule) {
    return state.runtimeModule;
  }

  if (!state.runtimeModulePromise) {
    state.runtimeModulePromise = import("./vendor/wllama/index.js")
      .then((module) => {
        state.runtimeModule = module;
        return module;
      })
      .catch((error) => {
        state.runtimeModulePromise = null;
        throw error;
      });
  }

  return state.runtimeModulePromise;
}

function buildWllamaAssets() {
  return {
    "single-thread/wllama.wasm": "./vendor/wllama/single-thread/wllama.wasm",
    "multi-thread/wllama.wasm": "./vendor/wllama/multi-thread/wllama.wasm",
  };
}

async function fetchModelBytes(modelUrl) {
  const response = await fetch(modelUrl, {
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`model fetch failed (${response.status})`);
  }

  return response.arrayBuffer();
}

function getThreadCount() {
  const hardwareThreads = Number(globalThis.navigator?.hardwareConcurrency || 4);
  return Math.max(1, Math.min(8, hardwareThreads));
}

async function ensureModelReady() {
  if (state.model && state.wllama) {
    return state.model;
  }

  if (state.modelLoadPromise) {
    return state.modelLoadPromise;
  }

  state.modelLoadPromise = (async () => {
    const { LoggerWithoutDebug, Wllama } = await ensureRuntimeModule();
    const config = state.config;

    if (!config?.modelUrl || !config?.modelFileName) {
      throw new Error("model configuration is incomplete");
    }

    setStatus(
      modelStatusEl,
      `モデルを読み込み中です...\n${config.modelFileName}\nsource: ${config.modelUrl}`
    );

    if (state.wllama) {
      await state.wllama.exit();
      state.wllama = null;
      state.model = null;
    }

    const bytes = await fetchModelBytes(config.modelUrl);
    const blob = new Blob([bytes], { type: "application/octet-stream" });
    const assets = buildWllamaAssets();
    const contextSize = Number(config.contextSize || 2048);
    const threadCount = getThreadCount();

    state.wllama = new Wllama(assets, {
      logger: LoggerWithoutDebug,
    });

    await state.wllama.loadModel([blob], {
      n_ctx: contextSize,
      n_threads: threadCount,
    });

    state.model = {
      fileName: config.modelFileName,
      size: bytes.byteLength,
      contextSize,
      threadCount,
    };

    setStatus(
      modelStatusEl,
      `モデル準備完了\n${state.model.fileName}\nsize: ${(state.model.size / 1024 / 1024).toFixed(1)} MB`,
      false,
      true
    );

    return state.model;
  })()
    .catch((error) => {
      const message = getErrorMessage(error);
      setStatus(modelStatusEl, `モデル初期化に失敗しました: ${message}`, true);
      throw error;
    })
    .finally(() => {
      state.modelLoadPromise = null;
    });

  return state.modelLoadPromise;
}

function buildMessagesFromPayload(payload) {
  const config = state.config || {};
  const messages = [];
  const systemPrompt = String(config.systemPrompt || "").trim();

  if (systemPrompt) {
    messages.push({
      role: "system",
      content: systemPrompt,
    });
  }

  const userContent =
    typeof payload === "string" ? payload : JSON.stringify(payload ?? { prompt: "", table: null });

  messages.push({
    role: "user",
    content: userContent,
  });

  return messages;
}

async function runInferenceForPayload(payload, { updateUi = true } = {}) {
  await ensureModelReady();

  const config = state.config || {};
  const messages = buildMessagesFromPayload(payload);
  let streamedText = "";

  const result = await state.wllama.createChatCompletion(messages, {
    nPredict: Number(config.maxTokens || 256),
    useCache: false,
    sampling: {
      temp: Number(config.temperature ?? 0.2),
      top_p: Number(config.topP ?? 0.9),
      top_k: Number(config.topK ?? 40),
    },
    onNewToken: (_token, piece, currentText) => {
      streamedText = currentText || `${streamedText}${piece || ""}`;
      if (updateUi) {
        setStatus(responseEl, streamedText || "推論中...");
      }
    },
  });

  return result || streamedText || "";
}

async function withInferenceLock(jobId, task) {
  if (state.inferenceInFlight) {
    throw new Error("inference is already running");
  }

  state.inferenceInFlight = true;
  state.currentJobId = jobId;
  publishBridgeStatus();
  renderRuntimeStatus();
  runBtn.disabled = true;

  try {
    return await task();
  } finally {
    state.inferenceInFlight = false;
    state.currentJobId = null;
    publishBridgeStatus();
    renderRuntimeStatus();
    runBtn.disabled = !state.bootstrapComplete;
  }
}

async function runManualPrompt(prompt, requestId = null) {
  const cleanPrompt = String(prompt ?? "").trim();
  if (!cleanPrompt) {
    throw new Error("prompt is empty");
  }

  setStatus(responseEl, "推論中...");
  const manualJobId = requestId || `manual-${Date.now()}`;
  const payload = {
    prompt: cleanPrompt,
    table: null,
  };

  const text = await withInferenceLock(manualJobId, () =>
    runInferenceForPayload(payload, { updateUi: true })
  );

  setStatus(responseEl, text || "(empty response)", false, true);
  return text;
}

async function callLLM(prompt, requestId = null) {
  try {
    const text = await runManualPrompt(prompt, requestId);
    if (requestId) {
      callHost("InferenceResult", requestId, text);
    }
    return text;
  } catch (error) {
    const message = getErrorMessage(error);
    if (requestId) {
      callHost("InferenceError", requestId, message);
    }
    throw error;
  }
}

async function fetchNextQueuedJob() {
  const response = await fetch("/queue/next", {
    cache: "no-store",
  });

  if (response.status === 204) {
    return null;
  }

  if (!response.ok) {
    throw new Error(`queue next request failed (${response.status})`);
  }

  return response.json();
}

async function postQueuedJobResult(jobId, resultText = null, errorText = null) {
  const body = {
    jobId,
  };

  if (errorText) {
    body.error = errorText;
  } else {
    body.result = String(resultText ?? "");
  }

  const response = await fetch("/queue/result", {
    method: "POST",
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
    cache: "no-store",
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    throw new Error(`queue result request failed (${response.status})`);
  }
}

async function processQueuedJob(job) {
  const jobId = String(job?.jobId || "").trim();
  if (!jobId) {
    throw new Error("queued job is missing jobId");
  }

  const payload = job?.payload ?? { prompt: "", table: null };
  setStatus(responseEl, `queue job ${jobId} を処理中...`);

  try {
    const text = await withInferenceLock(jobId, () =>
      runInferenceForPayload(payload, { updateUi: true })
    );
    await postQueuedJobResult(jobId, text, null);
    setStatus(responseEl, text || "(empty response)", false, true);
  } catch (error) {
    const message = getErrorMessage(error);
    setStatus(responseEl, `queue error (${jobId}): ${message}`, true);
    await postQueuedJobResult(jobId, null, message);
  }

  clearRuntimeNotice();
  renderRuntimeStatus();
  callHost("RequestRecalc");
}

async function pollQueueOnce() {
  if (!state.bootstrapComplete || state.queuePollInFlight || state.inferenceInFlight) {
    return;
  }

  state.queuePollInFlight = true;

  try {
    const job = await fetchNextQueuedJob();
    if (job) {
      await processQueuedJob(job);
    } else {
      clearRuntimeNotice();
      renderRuntimeStatus();
    }
  } catch (error) {
    console.error("[LLMExcel] queue poll failed", error);
    setRuntimeNotice(`queue error: ${getErrorMessage(error)}`, true);
  } finally {
    state.queuePollInFlight = false;
  }
}

function startQueuePolling() {
  if (state.queuePollTimer) {
    clearInterval(state.queuePollTimer);
  }

  const pollIntervalMs = getQueuePollIntervalMs();
  state.queuePollTimer = setInterval(() => {
    void pollQueueOnce();
  }, pollIntervalMs);

  void pollQueueOnce();
}

async function bootstrap() {
  runBtn.disabled = true;
  state.runtimeNotice = "ブラウザランタイムを確認中です...";
  state.runtimeNoticeIsError = false;
  renderRuntimeStatus();
  setStatus(modelStatusEl, "設定を取得しています...");

  try {
    state.webGpuInfo = await probeWebGpu();
    state.config = await fetchBridgeConfig();

    callHost(
      "BridgeBootstrap",
      JSON.stringify({
        runtimeKind: state.config.runtimeKind || "wllama-wasm",
        webGpuAvailable: state.webGpuInfo.available,
        webGpuLabel: state.webGpuInfo.label,
        crossOriginIsolated: window.crossOriginIsolated,
      })
    );

    clearRuntimeNotice();
    renderRuntimeStatus();

    await ensureModelReady();

    state.bootstrapComplete = true;
    clearRuntimeNotice();
    renderRuntimeStatus();
    publishBridgeStatus({ ready: true });
    startQueuePolling();
    runBtn.disabled = false;
  } catch (error) {
    const message = getErrorMessage(error);
    state.bootstrapComplete = false;
    setRuntimeNotice(`初期化失敗: ${message}`, true);
    callHost("BridgeError", message);
  }
}

window.__llmBridge = {
  callLLM,
  ensureModelReady,
  getStatus: getBridgeStatus,
  runManualPrompt,
};

runBtn.addEventListener("click", async () => {
  try {
    await runManualPrompt(promptInputEl.value);
  } catch (error) {
    setStatus(responseEl, `推論エラー: ${getErrorMessage(error)}`, true);
  }
});

void bootstrap();

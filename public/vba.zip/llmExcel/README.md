# llmExcel

Excel VBA からローカルの WebGPU LLM を `LLM(prompt, [range])` として呼び出すためのソース一式です。

## 構成

```text
Excel VBA
  -> hidden PowerShell HttpListener
  -> VBA-hosted WebView2
  -> global per-cell cache / job state
  -> async queue + result polling
  -> /app/index.html + /app/main.js
  -> wllama + GGUF model
```

PowerShell は静的配信に加えて `/queue/push`, `/queue/next`, `/queue/result`, `/bridge/config` を返します。
WebView2 上の `main.js` は 1 ジョブずつキューを消化し、結果を PowerShell の結果ストアへ戻します。

## リポジトリ構成

```text
llmExcel/
├─ README.md
├─ ps1/
│  └─ server.ps1
├─ tools/
│  └─ place-addin-objects.bat
├─ vba/
│  ├─ LLMBridge.bas
│  ├─ ThisWorkbook.cls
│  └─ webview2/
│     ├─ BridgeHostObject.cls
│     ├─ BridgeWebViewHost.cls
│     ├─ WebView2.cls
│     ├─ WebView2Controller.cls
│     ├─ WebView2Environment.cls
│     ├─ WebView2Handler.cls
│     ├─ WebView2Loader.cls
│     ├─ mWebView2Api.bas
│     ├─ mWebView2Callbacks.bas
│     ├─ mWebView2HandleMap.bas
│     ├─ mWebView2Helpers.bas
│     └─ mWebView2State.bas
├─ vendor/
│  ├─ webview2/
│  │  └─ WebView2Loader.dll
│  └─ wllama/
│     ├─ index.js
│     ├─ single-thread/
│     │  └─ wllama.wasm
│     └─ multi-thread/
│        └─ wllama.wasm
└─ web/
   ├─ index.html
   └─ main.js
```

## 使い方

1. `vba/` 配下の標準モジュール / クラスモジュール / `ThisWorkbook.cls` を `llmExcel.xlam` に取り込みます（埋め込み asset モジュールは不要です）。
2. 配置先PCで `tools\place-addin-objects.bat "C:\path\to\llmExcel.xlam"` を実行します。
3. バッチが `llmExcel.xlam` の隣に `vendor\`, `web\`, `ps1\` を配置します。
4. アドイン起動時に `%LOCALAPPDATA%\LLMExcel\` 以下へ実行用ファイルがコピーされます。
5. シート上で `=LLM("売上表を3行で要約")` や `=LLM("この表を要約", A1:C20)` のように使います。

## 挙動

- `LLM(prompt, [range])` は呼び出しセルごとに `SHA256(prompt + JSON(table))` の入力ハッシュを保持し、同じ入力では再推論せず `LastOutput` を返します。
- 同じセルが `Busy` / `Queued` の間に再計算されても、`LLM()` はそのセルの現在表示値を返し、空白なら `Busy` を返します。
- 入力が変わり、かつそのセルが未処理でない場合だけ VBA が `/queue/push` にジョブを投入し、セルは `Busy` を返します。
- `main.js` は `setInterval` で `/queue/next` をポーリングし、`inferenceInFlight` ロックで 1 ジョブずつ推論します。
- 推論完了後は `/queue/result` に結果を書き戻し、VBA 側で再計算をスケジュールします。

## 補足

- Host EXE は不要です。
- モデルのダウンロード・保存・バージョン管理は `LLMBridge.bas` が担当します。
- すべてのランタイムオブジェクト（`WebView2Loader.dll`, `index.js`, `wllama.wasm`, `web/*`, `ps1/server.ps1`）は VBA に埋め込まず、`llmExcel.xlam` 隣へ外部配置します。
- WebView2 Runtime 本体は Windows 側に存在する前提です。

## トラブルシューティング

- `Bundled runtime file was not found` と表示された場合は、`tools\place-addin-objects.bat "...\llmExcel.xlam"` を再実行してください。

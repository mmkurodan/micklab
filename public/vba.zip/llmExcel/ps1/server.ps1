param(
    [Parameter(Mandatory = $true)]
    [string]$RootPath,

    [int]$Port = 38473
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$resolvedRoot = [System.IO.Path]::GetFullPath($RootPath)
$appRoot = Join-Path $resolvedRoot 'web'
$modelsRoot = Join-Path $resolvedRoot 'models'
$configPath = Join-Path $resolvedRoot 'runtime-config.json'

foreach ($path in @($resolvedRoot, $appRoot, $modelsRoot)) {
    if (-not (Test-Path -LiteralPath $path)) {
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
}

$Global:Queue = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()
$Global:Results = [System.Collections.Generic.Dictionary[string, string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$Global:InFlightJobId = $null

function Set-CommonHeaders {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response
    )

    $Response.Headers['Cache-Control'] = 'no-store'
    $Response.Headers['Cross-Origin-Opener-Policy'] = 'same-origin'
    $Response.Headers['Cross-Origin-Embedder-Policy'] = 'require-corp'
    $Response.Headers['Cross-Origin-Resource-Policy'] = 'same-origin'
}

function Write-BytesResponse {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response,

        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [string]$ContentType,

        [int]$StatusCode = 200
    )

    $Response.StatusCode = $StatusCode
    $Response.ContentType = $ContentType
    $Response.ContentLength64 = $Bytes.Length
    Set-CommonHeaders -Response $Response
    if ($Bytes.Length -gt 0) {
        $Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
    }
}

function Write-TextResponse {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response,

        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Text,

        [string]$ContentType = 'text/plain; charset=utf-8',

        [int]$StatusCode = 200
    )

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    Write-BytesResponse -Response $Response -Bytes $bytes -ContentType $ContentType -StatusCode $StatusCode
}

function Write-JsonResponse {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response,

        [Parameter(Mandatory = $true)]
        $Value,

        [int]$StatusCode = 200
    )

    $jsonText = $Value | ConvertTo-Json -Depth 12 -Compress
    Write-TextResponse -Response $Response -Text $jsonText -ContentType 'application/json; charset=utf-8' -StatusCode $StatusCode
}

function Write-NoContentResponse {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response,

        [int]$StatusCode = 204
    )

    $Response.StatusCode = $StatusCode
    $Response.ContentLength64 = 0
    Set-CommonHeaders -Response $Response
}

function Get-ContentType {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        '.html' { return 'text/html; charset=utf-8' }
        '.js' { return 'application/javascript; charset=utf-8' }
        '.json' { return 'application/json; charset=utf-8' }
        '.css' { return 'text/css; charset=utf-8' }
        '.wasm' { return 'application/wasm' }
        '.gguf' { return 'application/octet-stream' }
        '.dll' { return 'application/octet-stream' }
        default { return 'application/octet-stream' }
    }
}

function Resolve-SafePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Root,

        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )

    $normalizedRoot = [System.IO.Path]::GetFullPath($Root)
    $safeRelative = $RelativePath.TrimStart('/', '\').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
    if ([string]::IsNullOrWhiteSpace($safeRelative)) {
        $safeRelative = 'index.html'
    }

    $candidatePath = [System.IO.Path]::GetFullPath((Join-Path $normalizedRoot $safeRelative))
    $rootPrefix = if ($normalizedRoot.EndsWith([System.IO.Path]::DirectorySeparatorChar.ToString())) {
        $normalizedRoot
    } else {
        $normalizedRoot + [System.IO.Path]::DirectorySeparatorChar
    }

    if (-not ($candidatePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase) -or $candidatePath.Equals($normalizedRoot, [System.StringComparison]::OrdinalIgnoreCase))) {
        throw 'FORBIDDEN'
    }

    return $candidatePath
}

function Serve-StaticFile {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerResponse]$Response,

        [Parameter(Mandatory = $true)]
        [string]$Root,

        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )

    $resolvedPath = Resolve-SafePath -Root $Root -RelativePath $RelativePath
    if (-not (Test-Path -LiteralPath $resolvedPath -PathType Leaf)) {
        Write-TextResponse -Response $Response -Text 'NOT_FOUND' -StatusCode 404
        return
    }

    $bytes = [System.IO.File]::ReadAllBytes($resolvedPath)
    $contentType = Get-ContentType -Path $resolvedPath
    Write-BytesResponse -Response $Response -Bytes $bytes -ContentType $contentType
}

function Read-RequestText {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerRequest]$Request
    )

    $reader = [System.IO.StreamReader]::new($Request.InputStream, [System.Text.Encoding]::UTF8)
    try {
        return $reader.ReadToEnd()
    } finally {
        $reader.Dispose()
    }
}

function Read-RequestJson {
    param(
        [Parameter(Mandatory = $true)]
        [System.Net.HttpListenerRequest]$Request
    )

    $bodyText = Read-RequestText -Request $Request
    if ([string]::IsNullOrWhiteSpace($bodyText)) {
        throw 'EMPTY_BODY'
    }

    return $bodyText | ConvertFrom-Json -Depth 12
}

function Get-QueueDepth {
    return $Global:Queue.Count
}

function Enqueue-Job {
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$Job
    )

    $Global:Queue.Enqueue($Job)
}

function Try-DequeueJob {
    param(
        [Parameter(Mandatory = $true)]
        [ref]$Job
    )

    $Job.Value = $null
    if ($null -ne $Global:InFlightJobId) {
        return $false
    }

    $candidate = $null
    if (-not $Global:Queue.TryDequeue([ref]$candidate)) {
        return $false
    }

    $Global:InFlightJobId = [string]$candidate.jobId
    $Job.Value = $candidate
    return $true
}

function Store-Result {
    param(
        [Parameter(Mandatory = $true)]
        [string]$JobId,

        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$ResultText
    )

    if ($Global:Results.ContainsKey($JobId)) {
        $Global:Results[$JobId] = $ResultText
    } else {
        $Global:Results.Add($JobId, $ResultText)
    }
    if ($Global:InFlightJobId -eq $JobId) {
        $Global:InFlightJobId = $null
    }
}

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        try {
            $path = $request.Url.AbsolutePath

            if ($request.HttpMethod -eq 'GET' -and $path -eq '/') {
                $response.StatusCode = 302
                $response.RedirectLocation = '/app/index.html'
                Set-CommonHeaders -Response $response
                continue
            }

            if ($request.HttpMethod -eq 'GET' -and $path -eq '/bridge/config') {
                if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
                    Write-TextResponse -Response $response -Text 'runtime config not found' -StatusCode 503
                    continue
                }

                $configBytes = [System.IO.File]::ReadAllBytes($configPath)
                Write-BytesResponse -Response $response -Bytes $configBytes -ContentType 'application/json; charset=utf-8'
                continue
            }

            if ($request.HttpMethod -eq 'POST' -and $path -eq '/queue/push') {
                $payload = Read-RequestJson -Request $request
                $jobId = [string]$payload.jobId
                if ([string]::IsNullOrWhiteSpace($jobId)) {
                    throw 'jobId is required'
                }

                if ($null -eq $payload.payload) {
                    throw 'payload is required'
                }

                $job = [pscustomobject]@{
                    jobId = $jobId
                    inputHash = [string]$payload.inputHash
                    payload = $payload.payload
                }

                Enqueue-Job -Job $job
                Write-JsonResponse -Response $response -Value ([pscustomobject]@{
                    ok = $true
                    jobId = $jobId
                    queued = Get-QueueDepth
                    inFlightJobId = $Global:InFlightJobId
                })
                continue
            }

            if ($request.HttpMethod -eq 'GET' -and $path -eq '/queue/next') {
                $nextJob = $null
                if (Try-DequeueJob -Job ([ref]$nextJob)) {
                    Write-JsonResponse -Response $response -Value $nextJob
                } else {
                    Write-NoContentResponse -Response $response
                }
                continue
            }

            if ($path -eq '/queue/result') {
                if ($request.HttpMethod -eq 'GET') {
                    $jobId = [string]$request.QueryString['jobId']
                    if ([string]::IsNullOrWhiteSpace($jobId)) {
                        throw 'jobId is required'
                    }

                    if ($Global:Results.ContainsKey($jobId)) {
                        $resultText = $Global:Results[$jobId]
                        [void]$Global:Results.Remove($jobId)
                        Write-TextResponse -Response $response -Text $resultText
                    } else {
                        Write-NoContentResponse -Response $response
                    }
                    continue
                }

                if ($request.HttpMethod -eq 'POST') {
                    $resultPayload = Read-RequestJson -Request $request
                    $jobId = [string]$resultPayload.jobId
                    if ([string]::IsNullOrWhiteSpace($jobId)) {
                        throw 'jobId is required'
                    }

                    $errorText = [string]$resultPayload.error
                    $resultText = if (-not [string]::IsNullOrWhiteSpace($errorText)) {
                        '#ERR ' + $errorText
                    } else {
                        [string]$resultPayload.result
                    }

                    Store-Result -JobId $jobId -ResultText $resultText
                    Write-JsonResponse -Response $response -Value ([pscustomobject]@{
                        ok = $true
                        jobId = $jobId
                    })
                    continue
                }
            }

            if ($request.HttpMethod -eq 'GET' -and $path.StartsWith('/app/', [System.StringComparison]::OrdinalIgnoreCase)) {
                Serve-StaticFile -Response $response -Root $appRoot -RelativePath $path.Substring(5)
                continue
            }

            if ($request.HttpMethod -eq 'GET' -and $path.StartsWith('/models/', [System.StringComparison]::OrdinalIgnoreCase)) {
                Serve-StaticFile -Response $response -Root $modelsRoot -RelativePath $path.Substring(8)
                continue
            }

            Write-TextResponse -Response $response -Text 'NOT_FOUND' -StatusCode 404
        } catch {
            Write-TextResponse -Response $response -Text $_.Exception.Message -StatusCode 500
        } finally {
            try {
                $response.OutputStream.Close()
            } catch {
            }

            try {
                $response.Close()
            } catch {
            }
        }
    }
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }

    $listener.Close()
}

@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo Usage: %~nx0 "C:\path\to\llmExcel.xlam"
    exit /b 1
)

set "ADDIN_PATH=%~1"
if /I not "%~x1"==".xlam" (
    echo [ERROR] Target must be an .xlam file path.
    exit /b 1
)

if /I not "%~nx1"=="llmExcel.xlam" (
    echo [ERROR] Add-in file name must be llmExcel.xlam
    exit /b 1
)

if not exist "%ADDIN_PATH%" (
    echo [ERROR] Add-in not found: "%ADDIN_PATH%"
    exit /b 1
)

set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..") do set "REPO_ROOT=%%~fI"
for %%I in ("%ADDIN_PATH%") do set "ADDIN_DIR=%%~dpI"

if not exist "%ADDIN_DIR%\vendor\webview2" mkdir "%ADDIN_DIR%\vendor\webview2"
if not exist "%ADDIN_DIR%\vendor\wllama\single-thread" mkdir "%ADDIN_DIR%\vendor\wllama\single-thread"
if not exist "%ADDIN_DIR%\vendor\wllama\multi-thread" mkdir "%ADDIN_DIR%\vendor\wllama\multi-thread"
if not exist "%ADDIN_DIR%\web" mkdir "%ADDIN_DIR%\web"
if not exist "%ADDIN_DIR%\ps1" mkdir "%ADDIN_DIR%\ps1"

call :copy_file "%REPO_ROOT%\vendor\webview2\WebView2Loader.dll" "%ADDIN_DIR%\vendor\webview2\WebView2Loader.dll" || exit /b 1
call :copy_file "%REPO_ROOT%\vendor\wllama\index.js" "%ADDIN_DIR%\vendor\wllama\index.js" || exit /b 1
call :copy_file "%REPO_ROOT%\vendor\wllama\single-thread\wllama.wasm" "%ADDIN_DIR%\vendor\wllama\single-thread\wllama.wasm" || exit /b 1
call :copy_file "%REPO_ROOT%\vendor\wllama\multi-thread\wllama.wasm" "%ADDIN_DIR%\vendor\wllama\multi-thread\wllama.wasm" || exit /b 1
call :copy_file "%REPO_ROOT%\web\index.html" "%ADDIN_DIR%\web\index.html" || exit /b 1
call :copy_file "%REPO_ROOT%\web\main.js" "%ADDIN_DIR%\web\main.js" || exit /b 1
call :copy_file "%REPO_ROOT%\ps1\server.ps1" "%ADDIN_DIR%\ps1\server.ps1" || exit /b 1

echo [OK] Objects deployed beside llmExcel.xlam at:
echo      "%ADDIN_DIR%"
exit /b 0

:copy_file
set "SRC=%~1"
set "DST=%~2"
if not exist "%SRC%" (
    echo [ERROR] Source file not found: "%SRC%"
    exit /b 1
)
for %%I in ("%SRC%") do set "SRC_FULL=%%~fI"
for %%I in ("%DST%") do set "DST_FULL=%%~fI"
if /I "%SRC_FULL%"=="%DST_FULL%" (
    echo [SKIP] %~nx1
    exit /b 0
)
copy /Y "%SRC%" "%DST%" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy: "%SRC%" ^> "%DST%"
    exit /b 1
)
echo [COPIED] %~nx1
exit /b 0

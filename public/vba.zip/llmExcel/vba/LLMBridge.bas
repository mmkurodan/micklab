Attribute VB_Name = "LLMBridge"
Option Explicit

#If VBA7 Then
    Private Declare PtrSafe Function URLDownloadToFile Lib "urlmon" Alias "URLDownloadToFileW" ( _
        ByVal pCaller As LongPtr, _
        ByVal szURL As LongPtr, _
        ByVal szFileName As LongPtr, _
        ByVal dwReserved As Long, _
        ByVal lpfnCB As LongPtr) As Long

    Private Declare PtrSafe Function SetDllDirectoryW Lib "kernel32" (ByVal lpPathName As LongPtr) As Long
    Private Declare PtrSafe Function CryptAcquireContext Lib "advapi32.dll" Alias "CryptAcquireContextW" ( _
        ByRef phProv As LongPtr, _
        ByVal pszContainer As LongPtr, _
        ByVal pszProvider As LongPtr, _
        ByVal dwProvType As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare PtrSafe Function CryptCreateHash Lib "advapi32.dll" ( _
        ByVal hProv As LongPtr, _
        ByVal Algid As Long, _
        ByVal hKey As LongPtr, _
        ByVal dwFlags As Long, _
        ByRef phHash As LongPtr) As Long
    Private Declare PtrSafe Function CryptHashData Lib "advapi32.dll" ( _
        ByVal hHash As LongPtr, _
        ByRef pbData As Any, _
        ByVal dwDataLen As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare PtrSafe Function CryptGetHashParam Lib "advapi32.dll" ( _
        ByVal hHash As LongPtr, _
        ByVal dwParam As Long, _
        ByRef pbData As Any, _
        ByRef pdwDataLen As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare PtrSafe Function CryptDestroyHash Lib "advapi32.dll" (ByVal hHash As LongPtr) As Long
    Private Declare PtrSafe Function CryptReleaseContext Lib "advapi32.dll" (ByVal hProv As LongPtr, ByVal dwFlags As Long) As Long
#Else
    Private Declare Function URLDownloadToFile Lib "urlmon" Alias "URLDownloadToFileW" ( _
        ByVal pCaller As Long, _
        ByVal szURL As Long, _
        ByVal szFileName As Long, _
        ByVal dwReserved As Long, _
        ByVal lpfnCB As Long) As Long

    Private Declare Function SetDllDirectoryW Lib "kernel32" (ByVal lpPathName As Long) As Long
    Private Declare Function CryptAcquireContext Lib "advapi32.dll" Alias "CryptAcquireContextW" ( _
        ByRef phProv As Long, _
        ByVal pszContainer As Long, _
        ByVal pszProvider As Long, _
        ByVal dwProvType As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare Function CryptCreateHash Lib "advapi32.dll" ( _
        ByVal hProv As Long, _
        ByVal Algid As Long, _
        ByVal hKey As Long, _
        ByVal dwFlags As Long, _
        ByRef phHash As Long) As Long
    Private Declare Function CryptHashData Lib "advapi32.dll" ( _
        ByVal hHash As Long, _
        ByRef pbData As Any, _
        ByVal dwDataLen As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare Function CryptGetHashParam Lib "advapi32.dll" ( _
        ByVal hHash As Long, _
        ByVal dwParam As Long, _
        ByRef pbData As Any, _
        ByRef pdwDataLen As Long, _
        ByVal dwFlags As Long) As Long
    Private Declare Function CryptDestroyHash Lib "advapi32.dll" (ByVal hHash As Long) As Long
    Private Declare Function CryptReleaseContext Lib "advapi32.dll" (ByVal hProv As Long, ByVal dwFlags As Long) As Long
#End If

Private Const APP_NAME As String = "LLMExcel"
Private Const DEFAULT_PORT As Long = 38473
Private Const DEFAULT_CONTEXT_SIZE As Long = 2048
Private Const DEFAULT_MAX_TOKENS As Long = 256
Private Const DEFAULT_TEMPERATURE As Double = 0.2
Private Const DEFAULT_TOP_P As Double = 0.9
Private Const DEFAULT_TOP_K As Long = 40
Private Const DEFAULT_QUEUE_POLL_INTERVAL_MS As Long = 750
Private Const STARTUP_TIMEOUT_SECONDS As Long = 300
Private Const BRIDGE_TIMEOUT_SECONDS As Long = 300
Private Const HTTP_TIMEOUT_SECONDS As Long = 10
Private Const DEFAULT_RUNTIME_KIND As String = "wllama-wasm"
Private Const DEFAULT_SYSTEM_PROMPT As String = "You are a concise spreadsheet assistant. Answer accurately and keep responses compact."
Private Const STATUS_IDLE As String = "Idle"
Private Const STATUS_QUEUED As String = "Queued"
Private Const STATUS_BUSY As String = "Busy"
Private Const STATUS_DONE As String = "Done"
Private Const BUSY_DISPLAY_TEXT As String = "Busy"
Private Const PROV_RSA_AES As Long = 24
Private Const CRYPT_VERIFYCONTEXT As Long = &HF0000000
Private Const CALG_SHA_256 As Long = &H800C
Private Const HP_HASHVAL As Long = &H2
Private Const SHA256_BYTE_LENGTH As Long = 32

Private Const DEFAULT_MODEL_FILE As String = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
Private Const DEFAULT_MODEL_URL As String = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true"
Private Const DEFAULT_MODEL_VERSION As String = "Qwen2.5-0.5B-Instruct-GGUF:qwen2.5-0.5b-instruct-q4_k_m:2026-03-21"

Private m_initialized As Boolean
Private m_serverProcessId As Long
Private m_webViewHost As BridgeWebViewHost
Private m_cellStates As Object
Private m_jobCells As Object
Private m_recalcScheduled As Boolean
Private m_recalcEarliestTime As Date

Private Type ModelDescriptor
    FileName As String
    SourceUrl As String
    VersionTag As String
End Type

Public Sub InitializeLLMBridge(Optional ByVal ShowErrors As Boolean = True)
    On Error GoTo EH

    EnsureStateStores
    EnsureServerReady
    EnsureWebViewBridge

    m_initialized = True
    Exit Sub

EH:
    m_initialized = False
    If ShowErrors Then
        MsgBox "LLM bridge initialization failed." & vbCrLf & vbCrLf & Err.Description, vbExclamation, APP_NAME
    End If
    Err.Raise Err.Number, "LLMBridge.InitializeLLMBridge", Err.Description
End Sub

Public Sub ShutdownLLMBridge()
    On Error Resume Next

    CancelDeferredCalculate

    If Not m_webViewHost Is Nothing Then
        m_webViewHost.Shutdown
        Set m_webViewHost = Nothing
    End If

    StopPowerShellServer
    m_initialized = False
End Sub

Public Sub ReloadLLMBridge()
    On Error GoTo EH

    EnsureServerReady
    EnsureWebView2LoaderReady

    If m_webViewHost Is Nothing Then
        EnsureWebViewBridge
    Else
        m_webViewHost.Reload
        m_webViewHost.WaitUntilReady STARTUP_TIMEOUT_SECONDS
    End If
    Exit Sub

EH:
    Err.Raise Err.Number, "LLMBridge.ReloadLLMBridge", Err.Description
End Sub

Public Sub ReinitializeLLMBridge()
    ShutdownLLMBridge
    InitializeLLMBridge True
End Sub

Public Function LLM(ByVal prompt As String, Optional ByVal optionalRange As Variant) As String
    Dim callerCell As Range
    Dim cellKey As String
    Dim state As Object
    Dim tableJson As String
    Dim payloadJson As String
    Dim inputHash As String
    Dim currentDisplay As String
    Dim hasOptionalRange As Boolean
    Dim previousJobId As String
    Dim newJobId As String

    On Error GoTo EH
    Application.Volatile True

    hasOptionalRange = Not IsMissing(optionalRange)
    Set callerCell = ResolveCallerCell()
    cellKey = BuildCellKey(callerCell)
    EnsureStateStores
    Set state = GetOrCreateCellState(cellKey)

    If Not InputHasWork(prompt, hasOptionalRange, optionalRange) Then
        ResetCellState state
        LLM = vbNullString
        Exit Function
    End If

    EnsureBridgeReady

    currentDisplay = GetCellDisplayedText(callerCell)
    RefreshCellState cellKey, state

    tableJson = BuildTableJson(hasOptionalRange, optionalRange)
    payloadJson = BuildPayloadJson(prompt, tableJson)
    inputHash = ComputeInputHash(prompt & tableJson)

    If StrComp(GetDictionaryString(state, "LastInputHash"), inputHash, vbBinaryCompare) = 0 Then
        LLM = GetDictionaryString(state, "LastOutput")
        Exit Function
    End If

    If StateIsPending(state) Then
        LLM = ChooseCurrentOrBusy(currentDisplay)
        Exit Function
    End If

    newJobId = CreateJobId()
    previousJobId = GetDictionaryString(state, "JobId")

    PushQueuedJob newJobId, inputHash, payloadJson

    UnregisterJob previousJobId
    RegisterJob newJobId, cellKey

    state.Item("LastInputHash") = inputHash
    state.Item("LastOutput") = BUSY_DISPLAY_TEXT
    state.Item("JobId") = newJobId
    state.Item("Status") = STATUS_QUEUED

    LLM = BUSY_DISPLAY_TEXT
    Exit Function

EH:
    LLM = "#ERR " & Err.Description
End Function

Public Function CallLLM(ByVal prompt As String, Optional ByVal optionalRange As Variant) As String
    If IsMissing(optionalRange) Then
        CallLLM = LLM(prompt)
    Else
        CallLLM = LLM(prompt, optionalRange)
    End If
End Function

Public Function BridgeStatus() As String
    If m_webViewHost Is Nothing Then
        If IsServerResponsive() Then
            BridgeStatus = "SERVER_READY"
        Else
            BridgeStatus = "STOPPED"
        End If
        Exit Function
    End If

    BridgeStatus = m_webViewHost.StatusText
End Function

Public Function BridgeStatusJson() As String
    If m_webViewHost Is Nothing Then
        BridgeStatusJson = vbNullString
    Else
        BridgeStatusJson = m_webViewHost.StatusJson
    End If
End Function

Public Sub HandleBridgeStatusUpdate(ByVal statusJson As String)
    Dim currentJobId As String
    Dim cellKey As String
    Dim state As Object

    On Error Resume Next
    EnsureStateStores

    If Not JsonBooleanProperty(statusJson, "inferenceBusy") Then
        Exit Sub
    End If

    currentJobId = JsonStringProperty(statusJson, "currentJobId")
    If LenB(currentJobId) = 0 Then
        Exit Sub
    End If

    If Not m_jobCells.Exists(currentJobId) Then
        Exit Sub
    End If

    cellKey = CStr(m_jobCells.Item(currentJobId))
    Set state = GetExistingCellState(cellKey)
    If state Is Nothing Then
        Exit Sub
    End If

    If StrComp(GetDictionaryString(state, "JobId"), currentJobId, vbTextCompare) = 0 Then
        state.Item("Status") = STATUS_BUSY
    End If
End Sub

Public Function RuntimeRootPath() As String
    RuntimeRootPath = GetRuntimeRoot
End Function

Public Function RuntimeModelPath() As String
    Dim descriptor As ModelDescriptor
    descriptor = GetDefaultModelDescriptor()
    RuntimeModelPath = BuildPath(GetModelsRoot, descriptor.FileName)
End Function

Public Function JsonStringLiteral(ByVal text As String) As String
    JsonStringLiteral = """" & JsonEscape(text) & """"
End Function

Public Sub ScheduleDeferredCalculate()
    On Error GoTo EH

    If m_recalcScheduled Then
        Exit Sub
    End If

    m_recalcEarliestTime = Now
    m_recalcScheduled = True
    Application.OnTime EarliestTime:=m_recalcEarliestTime, Procedure:=DeferredCalculateProcedureName(), Schedule:=True
    Exit Sub

EH:
    m_recalcScheduled = False
End Sub

Public Sub ProcessPendingRecalculation()
    On Error Resume Next
    m_recalcScheduled = False
    Application.Calculate
End Sub

Private Sub EnsureBridgeReady()
    If Not m_initialized Then
        InitializeLLMBridge False
        Exit Sub
    End If

    If Not IsServerResponsive() Then
        EnsureServerReady
        If Not m_webViewHost Is Nothing Then
            m_webViewHost.Reload
        End If
    End If

    EnsureWebViewBridge
End Sub

Private Sub EnsureServerReady()
    EnsureRuntimeLayout
    EnsureBundledRuntimeFilesReady
    EnsureModelDownloaded
    WriteRuntimeConfig
    EnsurePowerShellServer
End Sub

Private Sub EnsureWebViewBridge()
    EnsureWebView2LoaderReady

    If m_webViewHost Is Nothing Then
        Set m_webViewHost = New BridgeWebViewHost
        m_webViewHost.Initialize BridgeUrl("/app/index.html"), GetWebViewUserDataRoot, 1280, 720
    ElseIf LenB(m_webViewHost.LastError) <> 0 Then
        m_webViewHost.Reload
    End If

    m_webViewHost.WaitUntilReady STARTUP_TIMEOUT_SECONDS
End Sub

Private Sub EnsurePowerShellServer()
    If IsServerResponsive() Then
        Exit Sub
    End If

    StopPowerShellServer
    m_serverProcessId = StartHiddenProcess(BuildPowerShellCommand())
    WaitForServerReady STARTUP_TIMEOUT_SECONDS
End Sub

Private Sub StopPowerShellServer()
    On Error Resume Next

    If m_serverProcessId > 0 Then
        TerminateProcessById m_serverProcessId
        m_serverProcessId = 0
    End If
End Sub

Private Sub WaitForServerReady(ByVal timeoutSeconds As Long)
    Dim startedAt As Double

    startedAt = Timer
    Do
        If IsServerResponsive() Then
            Exit Sub
        End If

        DoEvents
        Sleep 100

        If ElapsedSeconds(startedAt) >= timeoutSeconds Then
            Err.Raise vbObjectError + 800, "LLMBridge.WaitForServerReady", "Timed out waiting for the PowerShell bridge server to start."
        End If
    Loop
End Sub

Private Function IsServerResponsive() As Boolean
    Dim configText As String

    On Error GoTo EH
    configText = HttpGetText(BridgeUrl("/bridge/config"), 5, False, False)
    IsServerResponsive = (LenB(configText) <> 0)
    Exit Function

EH:
    IsServerResponsive = False
End Function

Private Sub EnsureBundledRuntimeFilesReady()
    CopyBundledRuntimeFile "ps1\server.ps1", BuildPath(GetPsRoot, "server.ps1")
    CopyBundledRuntimeFile "web\index.html", BuildPath(GetWebRuntimeRoot, "index.html")
    CopyBundledRuntimeFile "web\main.js", BuildPath(GetWebRuntimeRoot, "main.js")
    CopyBundledRuntimeFile "vendor\wllama\index.js", BuildPath(GetWebRuntimeRoot, "vendor\wllama\index.js")
    CopyBundledRuntimeFile "vendor\wllama\single-thread\wllama.wasm", BuildPath(GetWebRuntimeRoot, "vendor\wllama\single-thread\wllama.wasm")
    CopyBundledRuntimeFile "vendor\wllama\multi-thread\wllama.wasm", BuildPath(GetWebRuntimeRoot, "vendor\wllama\multi-thread\wllama.wasm")
End Sub

Private Sub CopyBundledRuntimeFile(ByVal sourceRelativePath As String, ByVal targetPath As String)
    Dim sourcePath As String

    sourcePath = FindBundledFile(sourceRelativePath)
    If LenB(sourcePath) = 0 Then
        Err.Raise vbObjectError + 813, "LLMBridge.CopyBundledRuntimeFile", _
            "Bundled runtime file was not found: " & sourceRelativePath & ". Run tools\place-addin-objects.bat to deploy objects beside llmExcel.xlam."
    End If

    CopyFileOverwrite sourcePath, targetPath
End Sub

Private Sub EnsureWebView2LoaderReady()
    Dim bundledLoaderPath As String
    Dim installedLoaderPath As String
    Dim runtimeLoaderPath As String

    runtimeLoaderPath = BuildPath(GetBinaryRoot, "WebView2Loader.dll")
    bundledLoaderPath = FindBundledWebView2Loader()
    installedLoaderPath = FindInstalledWebView2Loader()

    If LenB(bundledLoaderPath) <> 0 Then
        CopyFileOverwrite bundledLoaderPath, runtimeLoaderPath
    ElseIf LenB(installedLoaderPath) <> 0 Then
        If StrComp(installedLoaderPath, runtimeLoaderPath, vbTextCompare) <> 0 Then
            CopyFileOverwrite installedLoaderPath, runtimeLoaderPath
        End If
    End If

    If Not FileExists(runtimeLoaderPath) Then
        Err.Raise vbObjectError + 801, "LLMBridge.EnsureWebView2LoaderReady", _
            "WebView2Loader.dll was not found. Distribute it with the add-in (vendor\webview2\WebView2Loader.dll) or install WebView2 Runtime."
    End If

    If SetDllDirectoryW(StrPtr(GetBinaryRoot)) = 0 Then
        Err.Raise vbObjectError + 806, "LLMBridge.EnsureWebView2LoaderReady", "Failed to register the runtime bin folder as a DLL search path."
    End If
End Sub

Private Function FindBundledWebView2Loader() As String
    Dim candidates(0 To 1) As String
    Dim index As Long

    candidates(0) = FindBundledFile("vendor\webview2\WebView2Loader.dll")
    candidates(1) = FindBundledFile("WebView2Loader.dll")

    For index = LBound(candidates) To UBound(candidates)
        If LenB(candidates(index)) <> 0 Then
            FindBundledWebView2Loader = candidates(index)
            Exit Function
        End If
    Next index
End Function

Private Sub EnsureModelDownloaded()
    Dim descriptor As ModelDescriptor
    Dim modelPath As String
    Dim versionPath As String
    Dim currentVersion As String

    descriptor = GetDefaultModelDescriptor()
    modelPath = BuildPath(GetModelsRoot, descriptor.FileName)
    versionPath = modelPath & ".version.txt"
    currentVersion = Trim$(ReadUtf8TextFileIfExists(versionPath))

    If FileExists(modelPath) Then
        If FileLen(modelPath) > 0 And StrComp(currentVersion, descriptor.VersionTag, vbTextCompare) = 0 Then
            Exit Sub
        End If
    End If

    DownloadFile descriptor.SourceUrl, modelPath
    WriteUtf8TextFile versionPath, descriptor.VersionTag
    WriteUtf8TextFile BuildPath(GetModelsRoot, "model-manifest.json"), BuildModelManifest(descriptor)
End Sub

Private Function BuildModelManifest(ByRef descriptor As ModelDescriptor) As String
    BuildModelManifest = "{" & vbLf & _
        "  ""fileName"": """ & JsonEscape(descriptor.FileName) & """," & vbLf & _
        "  ""sourceUrl"": """ & JsonEscape(descriptor.SourceUrl) & """," & vbLf & _
        "  ""version"": """ & JsonEscape(descriptor.VersionTag) & """" & vbLf & _
        "}"
End Function

Private Sub WriteRuntimeConfig()
    Dim descriptor As ModelDescriptor
    Dim jsonText As String

    descriptor = GetDefaultModelDescriptor()
    jsonText = "{" & vbLf & _
        "  ""modelFileName"": """ & JsonEscape(descriptor.FileName) & """," & vbLf & _
        "  ""modelUrl"": ""/models/" & JsonEscape(descriptor.FileName) & """," & vbLf & _
        "  ""contextSize"": " & CStr(DEFAULT_CONTEXT_SIZE) & "," & vbLf & _
        "  ""maxTokens"": " & CStr(DEFAULT_MAX_TOKENS) & "," & vbLf & _
        "  ""temperature"": " & Replace(CStr(DEFAULT_TEMPERATURE), ",", ".") & "," & vbLf & _
        "  ""topP"": " & Replace(CStr(DEFAULT_TOP_P), ",", ".") & "," & vbLf & _
        "  ""topK"": " & CStr(DEFAULT_TOP_K) & "," & vbLf & _
        "  ""bridgeTimeoutSeconds"": " & CStr(BRIDGE_TIMEOUT_SECONDS) & "," & vbLf & _
        "  ""queuePollIntervalMs"": " & CStr(DEFAULT_QUEUE_POLL_INTERVAL_MS) & "," & vbLf & _
        "  ""runtimeKind"": """ & JsonEscape(DEFAULT_RUNTIME_KIND) & """," & vbLf & _
        "  ""systemPrompt"": """ & JsonEscape(DEFAULT_SYSTEM_PROMPT) & """" & vbLf & _
        "}"

    WriteUtf8TextFile BuildPath(GetRuntimeRoot, "runtime-config.json"), jsonText
End Sub

Private Function GetDefaultModelDescriptor() As ModelDescriptor
    GetDefaultModelDescriptor.FileName = DEFAULT_MODEL_FILE
    GetDefaultModelDescriptor.SourceUrl = DEFAULT_MODEL_URL
    GetDefaultModelDescriptor.VersionTag = DEFAULT_MODEL_VERSION
End Function

Private Function FindInstalledWebView2Loader() As String
    Dim candidates(0 To 3) As String
    Dim applicationPath As String
    Dim programFiles As String
    Dim programFilesX86 As String
    Dim index As Long

    applicationPath = Application.Path
    programFiles = Environ$("ProgramFiles")
    programFilesX86 = Environ$("ProgramFiles(x86)")

    candidates(0) = BuildPath(applicationPath, "ADDINS\Microsoft Power Query for Excel Integrated\bin\WebView2Loader.dll")
    candidates(1) = BuildPath(programFiles, "Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\WebView2Loader.dll")
    candidates(2) = BuildPath(programFilesX86, "Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\WebView2Loader.dll")
    candidates(3) = BuildPath(programFiles, "Microsoft\EdgeWebView\Application\WebView2Loader.dll")

    For index = LBound(candidates) To UBound(candidates)
        If LenB(candidates(index)) <> 0 Then
            If FileExists(candidates(index)) Then
                FindInstalledWebView2Loader = candidates(index)
                Exit Function
            End If
        End If
    Next index
End Function

Private Function BuildPowerShellCommand() As String
    BuildPowerShellCommand = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & _
        Quote(BuildPath(GetPsRoot, "server.ps1")) & _
        " -RootPath " & Quote(GetRuntimeRoot) & _
        " -Port " & CStr(DEFAULT_PORT)
End Function

Private Function StartHiddenProcess(ByVal commandLine As String) As Long
    Dim processClass As Object
    Dim startup As Object
    Dim processId As Variant
    Dim resultCode As Long

    Set processClass = GetObject("winmgmts:root\cimv2:Win32_Process")
    Set startup = GetObject("winmgmts:root\cimv2:Win32_ProcessStartup").SpawnInstance_
    startup.ShowWindow = 0

    resultCode = processClass.Create(commandLine, Null, startup, processId)
    If resultCode <> 0 Then
        Err.Raise vbObjectError + 802, "LLMBridge.StartHiddenProcess", "Failed to start a hidden process. WMI error code=" & CStr(resultCode)
    End If

    StartHiddenProcess = CLng(processId)
End Function

Private Sub TerminateProcessById(ByVal processId As Long)
    Dim service As Object
    Dim processes As Object
    Dim processItem As Object

    Set service = GetObject("winmgmts:root\cimv2")
    Set processes = service.ExecQuery("SELECT * FROM Win32_Process WHERE ProcessId = " & CStr(processId))

    For Each processItem In processes
        processItem.Terminate 0
    Next processItem
End Sub

Private Sub PushQueuedJob(ByVal jobId As String, ByVal inputHash As String, ByVal payloadJson As String)
    Dim requestText As String

    requestText = "{" & _
        """jobId"":" & JsonStringLiteral(jobId) & "," & _
        """inputHash"":" & JsonStringLiteral(inputHash) & "," & _
        """payload"":" & payloadJson & _
        "}"

    HttpPostText BridgeUrl("/queue/push"), requestText, HTTP_TIMEOUT_SECONDS
End Sub

Private Function TryReadJobResultFromServer(ByVal jobId As String, ByRef resultText As String) As Boolean
    Dim statusCode As Long

    resultText = HttpGetText(BridgeUrl("/queue/result?jobId=" & jobId), HTTP_TIMEOUT_SECONDS, True, False, statusCode)
    TryReadJobResultFromServer = (statusCode = 200)
End Function

Private Function HttpGetText(ByVal url As String, ByVal timeoutSeconds As Long, ByVal noContentOk As Boolean, _
    ByVal acceptErrors As Boolean, Optional ByRef statusCode As Long = 0) As String

    HttpGetText = HttpRequestText("GET", url, vbNullString, vbNullString, timeoutSeconds, noContentOk, acceptErrors, statusCode)
End Function

Private Function HttpPostText(ByVal url As String, ByVal bodyText As String, ByVal timeoutSeconds As Long, _
    Optional ByRef statusCode As Long = 0) As String

    HttpPostText = HttpRequestText("POST", url, bodyText, "application/json; charset=utf-8", timeoutSeconds, False, False, statusCode)
End Function

Private Function HttpRequestText(ByVal methodName As String, ByVal url As String, ByVal bodyText As String, _
    ByVal contentType As String, ByVal timeoutSeconds As Long, ByVal noContentOk As Boolean, _
    ByVal acceptErrors As Boolean, Optional ByRef statusCode As Long = 0) As String

    Dim request As Object
    Dim responseBytes As Variant
    Dim responseText As String
    Dim requestBytes As Variant

    Set request = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    request.setTimeouts 30000, 30000, timeoutSeconds * 1000, timeoutSeconds * 1000
    request.Open methodName, url, False
    request.setRequestHeader "Cache-Control", "no-store"

    If LenB(contentType) <> 0 Then
        request.setRequestHeader "Content-Type", contentType
    End If

    If LenB(bodyText) = 0 Then
        request.Send
    Else
        requestBytes = Utf8BytesFromString(bodyText)
        request.Send requestBytes
    End If

    statusCode = CLng(request.Status)

    If statusCode = 204 And noContentOk Then
        HttpRequestText = vbNullString
        Exit Function
    End If

    On Error Resume Next
    responseBytes = request.responseBody
    On Error GoTo 0

    If IsEmpty(responseBytes) Then
        responseText = vbNullString
    Else
        responseText = Utf8StringFromBytes(responseBytes)
    End If

    If (statusCode < 200 Or statusCode >= 300) And Not acceptErrors Then
        Err.Raise vbObjectError + 803, "LLMBridge.HttpRequestText", _
            "HTTP " & CStr(statusCode) & " from " & url & IIf(LenB(responseText) = 0, vbNullString, ": " & responseText)
    End If

    HttpRequestText = responseText
End Function

Private Sub RefreshCellState(ByVal cellKey As String, ByVal state As Object)
    Dim jobId As String
    Dim resultText As String
    Dim currentBusyJobId As String

    jobId = GetDictionaryString(state, "JobId")
    If LenB(jobId) = 0 Then
        If LenB(GetDictionaryString(state, "LastInputHash")) = 0 Then
            state.Item("Status") = STATUS_IDLE
        End If
        Exit Sub
    End If

    If TryReadJobResultFromServer(jobId, resultText) Then
        state.Item("LastOutput") = resultText
        state.Item("Status") = STATUS_DONE
        state.Item("JobId") = vbNullString
        UnregisterJob jobId
        Exit Sub
    End If

    currentBusyJobId = CurrentBusyJobId()
    If LenB(currentBusyJobId) <> 0 And StrComp(currentBusyJobId, jobId, vbTextCompare) = 0 Then
        state.Item("Status") = STATUS_BUSY
    ElseIf StateIsPending(state) Then
        state.Item("Status") = STATUS_QUEUED
    End If
End Sub

Private Function ChooseCurrentOrBusy(ByVal currentDisplay As String) As String
    If LenB(currentDisplay) <> 0 Then
        ChooseCurrentOrBusy = currentDisplay
    Else
        ChooseCurrentOrBusy = BUSY_DISPLAY_TEXT
    End If
End Function

Private Function InputHasWork(ByVal prompt As String, ByVal hasOptionalRange As Boolean, ByRef optionalRange As Variant) As Boolean
    InputHasWork = (LenB(Trim$(prompt)) <> 0)
    If InputHasWork Then
        Exit Function
    End If

    If Not hasOptionalRange Then
        Exit Function
    End If

    If IsObject(optionalRange) Then
        InputHasWork = Not (optionalRange Is Nothing)
    ElseIf Not IsEmpty(optionalRange) Then
        InputHasWork = True
    End If
End Function

Private Function BuildPayloadJson(ByVal prompt As String, ByVal tableJson As String) As String
    BuildPayloadJson = "{" & _
        """prompt"":" & JsonStringLiteral(prompt) & "," & _
        """table"":" & tableJson & _
        "}"
End Function

Private Function BuildTableJson(ByVal hasOptionalRange As Boolean, ByRef optionalRange As Variant) As String
    Dim sourceRange As Range

    If Not hasOptionalRange Then
        BuildTableJson = "null"
        Exit Function
    End If

    If IsObject(optionalRange) Then
        If TypeName(optionalRange) = "Range" Then
            Set sourceRange = optionalRange
        End If
    End If

    If sourceRange Is Nothing Then
        If IsEmpty(optionalRange) Then
            BuildTableJson = "null"
        Else
            BuildTableJson = "[[" & SerializeJsonValue(optionalRange) & "]]"
        End If
        Exit Function
    End If

    BuildTableJson = RangeToJsonTable(sourceRange)
End Function

Private Function RangeToJsonTable(ByVal sourceRange As Range) As String
    Dim values As Variant
    Dim rowIndex As Long
    Dim columnIndex As Long
    Dim jsonText As String

    values = sourceRange.Value2

    If sourceRange.Rows.Count = 1 And sourceRange.Columns.Count = 1 Then
        RangeToJsonTable = "[[" & SerializeJsonValue(values) & "]]"
        Exit Function
    End If

    jsonText = "["
    For rowIndex = 1 To sourceRange.Rows.Count
        If rowIndex > 1 Then
            jsonText = jsonText & ","
        End If

        jsonText = jsonText & "["
        For columnIndex = 1 To sourceRange.Columns.Count
            If columnIndex > 1 Then
                jsonText = jsonText & ","
            End If
            jsonText = jsonText & SerializeJsonValue(values(rowIndex, columnIndex))
        Next columnIndex
        jsonText = jsonText & "]"
    Next rowIndex
    jsonText = jsonText & "]"

    RangeToJsonTable = jsonText
End Function

Private Function SerializeJsonValue(ByVal value As Variant) As String
    If IsError(value) Then
        SerializeJsonValue = JsonStringLiteral(ExcelErrorText(CLng(value)))
        Exit Function
    End If

    Select Case VarType(value)
        Case vbEmpty, vbNull
            SerializeJsonValue = "null"
        Case vbBoolean
            SerializeJsonValue = IIf(CBool(value), "true", "false")
        Case vbByte, vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal
            SerializeJsonValue = NormalizeJsonNumber(value)
        Case vbDate
            SerializeJsonValue = NormalizeJsonNumber(CDbl(value))
        Case Else
            If IsNumeric(value) Then
                SerializeJsonValue = NormalizeJsonNumber(value)
            Else
                SerializeJsonValue = JsonStringLiteral(CStr(value))
            End If
    End Select
End Function

Private Function NormalizeJsonNumber(ByVal value As Variant) As String
    NormalizeJsonNumber = Replace(CStr(value), ",", ".")
End Function

Private Function ExcelErrorText(ByVal errorCode As Long) As String
    Select Case errorCode
        Case xlErrDiv0
            ExcelErrorText = "#DIV/0!"
        Case xlErrNA
            ExcelErrorText = "#N/A"
        Case xlErrName
            ExcelErrorText = "#NAME?"
        Case xlErrNull
            ExcelErrorText = "#NULL!"
        Case xlErrNum
            ExcelErrorText = "#NUM!"
        Case xlErrRef
            ExcelErrorText = "#REF!"
        Case xlErrValue
            ExcelErrorText = "#VALUE!"
        Case xlErrGettingData
            ExcelErrorText = "#GETTING_DATA"
        Case Else
            ExcelErrorText = "#ERR"
    End Select
End Function

Private Function ComputeInputHash(ByVal text As String) As String
    #If VBA7 Then
        Dim providerHandle As LongPtr
        Dim hashHandle As LongPtr
    #Else
        Dim providerHandle As Long
        Dim hashHandle As Long
    #End If
    Dim dataBytes As Variant
    Dim hashBytes(0 To SHA256_BYTE_LENGTH - 1) As Byte
    Dim hashLength As Long
    Dim errorNumber As Long
    Dim errorDescription As String

    On Error GoTo EH

    dataBytes = Utf8BytesFromString(text)

    If CryptAcquireContext(providerHandle, 0, 0, PROV_RSA_AES, CRYPT_VERIFYCONTEXT) = 0 Then
        Err.Raise vbObjectError + 808, "LLMBridge.ComputeInputHash", "Failed to acquire a cryptographic context for SHA-256."
    End If

    If CryptCreateHash(providerHandle, CALG_SHA_256, 0, 0, hashHandle) = 0 Then
        Err.Raise vbObjectError + 809, "LLMBridge.ComputeInputHash", "Failed to create the SHA-256 hash object."
    End If

    If ByteArrayLength(dataBytes) > 0 Then
        If CryptHashData(hashHandle, dataBytes(LBound(dataBytes)), ByteArrayLength(dataBytes), 0) = 0 Then
            Err.Raise vbObjectError + 810, "LLMBridge.ComputeInputHash", "Failed to hash the input payload."
        End If
    End If

    hashLength = SHA256_BYTE_LENGTH
    If CryptGetHashParam(hashHandle, HP_HASHVAL, hashBytes(0), hashLength, 0) = 0 Then
        Err.Raise vbObjectError + 811, "LLMBridge.ComputeInputHash", "Failed to read the SHA-256 digest."
    End If

    ComputeInputHash = BytesToHexString(hashBytes)
    GoTo Cleanup

EH:
    errorNumber = Err.Number
    errorDescription = Err.Description
    If errorNumber = 0 Then
        errorNumber = vbObjectError + 812
        errorDescription = "Unknown SHA-256 hashing failure."
    End If
    GoTo Cleanup

Cleanup:
    On Error Resume Next
    If hashHandle <> 0 Then
        CryptDestroyHash hashHandle
    End If
    If providerHandle <> 0 Then
        CryptReleaseContext providerHandle, 0
    End If
    On Error GoTo 0
    If errorNumber <> 0 Then
        Err.Raise errorNumber, "LLMBridge.ComputeInputHash", errorDescription
    End If
End Function

Private Function CreateJobId() As String
    Dim guidText As String

    On Error Resume Next
    guidText = Replace$(Replace$(CreateObject("Scriptlet.TypeLib").GUID, "{", vbNullString), "}", vbNullString)
    On Error GoTo 0

    If LenB(guidText) = 0 Then
        Randomize Timer
        guidText = Format$(Now, "yyyymmddhhnnss") & "-" & Hex$(CLng(Rnd() * 2147483647#))
    End If

    CreateJobId = "job-" & guidText
End Function

Private Sub EnsureStateStores()
    If m_cellStates Is Nothing Then
        Set m_cellStates = CreateObject("Scripting.Dictionary")
        m_cellStates.CompareMode = vbTextCompare
    End If

    If m_jobCells Is Nothing Then
        Set m_jobCells = CreateObject("Scripting.Dictionary")
        m_jobCells.CompareMode = vbTextCompare
    End If
End Sub

Private Function GetOrCreateCellState(ByVal cellKey As String) As Object
    EnsureStateStores

    If Not m_cellStates.Exists(cellKey) Then
        m_cellStates.Add cellKey, CreateCellState()
    End If

    Set GetOrCreateCellState = m_cellStates.Item(cellKey)
End Function

Private Function GetExistingCellState(ByVal cellKey As String) As Object
    EnsureStateStores
    If m_cellStates.Exists(cellKey) Then
        Set GetExistingCellState = m_cellStates.Item(cellKey)
    End If
End Function

Private Function CreateCellState() As Object
    Dim state As Object

    Set state = CreateObject("Scripting.Dictionary")
    state.CompareMode = vbTextCompare
    state.Add "LastInputHash", vbNullString
    state.Add "LastOutput", vbNullString
    state.Add "JobId", vbNullString
    state.Add "Status", STATUS_IDLE

    Set CreateCellState = state
End Function

Private Sub ResetCellState(ByVal state As Object)
    Dim oldJobId As String

    oldJobId = GetDictionaryString(state, "JobId")
    UnregisterJob oldJobId

    state.Item("LastInputHash") = vbNullString
    state.Item("LastOutput") = vbNullString
    state.Item("JobId") = vbNullString
    state.Item("Status") = STATUS_IDLE
End Sub

Private Function StateIsPending(ByVal state As Object) As Boolean
    Dim statusValue As String

    statusValue = GetDictionaryString(state, "Status")
    StateIsPending = (StrComp(statusValue, STATUS_QUEUED, vbTextCompare) = 0 Or StrComp(statusValue, STATUS_BUSY, vbTextCompare) = 0)
End Function

Private Function GetDictionaryString(ByVal dictionary As Object, ByVal keyName As String) As String
    If dictionary Is Nothing Then
        Exit Function
    End If

    If dictionary.Exists(keyName) Then
        GetDictionaryString = CStr(dictionary.Item(keyName))
    End If
End Function

Private Sub RegisterJob(ByVal jobId As String, ByVal cellKey As String)
    EnsureStateStores
    If LenB(jobId) = 0 Then
        Exit Sub
    End If

    If m_jobCells.Exists(jobId) Then
        m_jobCells.Remove jobId
    End If
    m_jobCells.Add jobId, cellKey
End Sub

Private Sub UnregisterJob(ByVal jobId As String)
    EnsureStateStores
    If LenB(jobId) = 0 Then
        Exit Sub
    End If

    If m_jobCells.Exists(jobId) Then
        m_jobCells.Remove jobId
    End If
End Sub

Private Function CurrentBusyJobId() As String
    If IsBridgeBusy() Then
        CurrentBusyJobId = JsonStringProperty(BridgeStatusJson(), "currentJobId")
    End If
End Function

Private Function IsBridgeBusy() As Boolean
    IsBridgeBusy = JsonBooleanProperty(BridgeStatusJson(), "inferenceBusy")
End Function

Private Function JsonBooleanProperty(ByVal jsonText As String, ByVal propertyName As String) As Boolean
    Dim compactJson As String
    compactJson = CompactJson(jsonText)
    JsonBooleanProperty = (InStr(1, compactJson, """" & propertyName & """:true", vbTextCompare) > 0)
End Function

Private Function JsonStringProperty(ByVal jsonText As String, ByVal propertyName As String) As String
    Dim compactJson As String
    Dim propertyToken As String
    Dim startIndex As Long
    Dim valueStart As Long
    Dim valueEnd As Long

    compactJson = CompactJson(jsonText)
    propertyToken = """" & propertyName & """:"""
    startIndex = InStr(1, compactJson, propertyToken, vbTextCompare)
    If startIndex = 0 Then
        Exit Function
    End If

    valueStart = startIndex + Len(propertyToken)
    valueEnd = InStr(valueStart, compactJson, """")
    If valueEnd = 0 Then
        Exit Function
    End If

    JsonStringProperty = Mid$(compactJson, valueStart, valueEnd - valueStart)
End Function

Private Function CompactJson(ByVal jsonText As String) As String
    Dim compactText As String

    compactText = Replace(jsonText, vbCr, vbNullString)
    compactText = Replace(compactText, vbLf, vbNullString)
    compactText = Replace(compactText, vbTab, vbNullString)
    compactText = Replace(compactText, " ", vbNullString)
    CompactJson = compactText
End Function

Private Function ResolveCallerCell() As Range
    On Error Resume Next

    If TypeName(Application.Caller) = "Range" Then
        Set ResolveCallerCell = Application.Caller.Cells(1, 1)
    End If
End Function

Private Function ResolveRangeCell(ByRef reference As Variant) As Range
    On Error Resume Next

    If IsObject(reference) Then
        If TypeName(reference) = "Range" Then
            Set ResolveRangeCell = reference.Cells(1, 1)
        End If
    End If
End Function

Private Function BuildCellKey(ByVal callerCell As Range) As String
    Dim workbookId As String
    Dim worksheetId As String
    Dim addressText As String

    If callerCell Is Nothing Then
        BuildCellKey = "GLOBAL"
        Exit Function
    End If

    workbookId = callerCell.Worksheet.Parent.Name
    worksheetId = callerCell.Worksheet.Name

    addressText = callerCell.Address(False, False, xlA1)
    BuildCellKey = workbookId & "!" & worksheetId & "!" & addressText
End Function

Private Function GetCellDisplayedText(ByVal callerCell As Range) As String
    On Error Resume Next
    If callerCell Is Nothing Then
        Exit Function
    End If

    GetCellDisplayedText = CStr(callerCell.Text)
End Function

Private Function DeferredCalculateProcedureName() As String
    DeferredCalculateProcedureName = "'" & ThisWorkbook.Name & "'!LLMBridge.ProcessPendingRecalculation"
End Function

Private Sub CancelDeferredCalculate()
    On Error Resume Next

    If m_recalcScheduled Then
        Application.OnTime EarliestTime:=m_recalcEarliestTime, Procedure:=DeferredCalculateProcedureName(), Schedule:=False
    End If

    m_recalcScheduled = False
End Sub

Private Sub DownloadFile(ByVal sourceUrl As String, ByVal targetPath As String)
    Dim resultCode As Long

    DeleteFileIfExists targetPath
    EnsureFolder GetParentFolder(targetPath)

    resultCode = URLDownloadToFile(0, StrPtr(sourceUrl), StrPtr(targetPath), 0, 0)
    If resultCode <> S_OK Or Not FileExists(targetPath) Then
        DeleteFileIfExists targetPath
        Err.Raise vbObjectError + 804, "LLMBridge.DownloadFile", "Download failed: " & sourceUrl & " -> " & targetPath & " (HRESULT=" & CStr(resultCode) & ")"
    End If

    If FileLen(targetPath) = 0 Then
        DeleteFileIfExists targetPath
        Err.Raise vbObjectError + 805, "LLMBridge.DownloadFile", "Download produced an empty file: " & targetPath
    End If
End Sub

Private Sub EnsureRuntimeLayout()
    EnsureFolder GetRuntimeRoot
    EnsureFolder GetBinaryRoot
    EnsureFolder GetWebRuntimeRoot
    EnsureFolder BuildPath(GetWebRuntimeRoot, "vendor")
    EnsureFolder BuildPath(GetWebRuntimeRoot, "vendor\wllama")
    EnsureFolder BuildPath(GetWebRuntimeRoot, "vendor\wllama\single-thread")
    EnsureFolder BuildPath(GetWebRuntimeRoot, "vendor\wllama\multi-thread")
    EnsureFolder GetModelsRoot
    EnsureFolder GetPsRoot
    EnsureFolder GetUserDataRoot
    EnsureFolder GetWebViewUserDataRoot
End Sub

Private Function BridgeUrl(ByVal routePath As String) As String
    BridgeUrl = "http://127.0.0.1:" & CStr(DEFAULT_PORT) & routePath
End Function

Private Function GetRuntimeRoot() As String
    Dim localAppData As String

    localAppData = Environ$("LOCALAPPDATA")
    If LenB(localAppData) = 0 Then
        localAppData = Environ$("TEMP")
    End If

    GetRuntimeRoot = BuildPath(localAppData, APP_NAME)
End Function

Private Function GetAddinRoot() As String
    On Error Resume Next
    GetAddinRoot = ThisWorkbook.Path
    If LenB(GetAddinRoot) = 0 Then
        GetAddinRoot = CurDir$
    End If
End Function

Private Function FindBundledFile(ByVal relativePath As String) As String
    Dim addinRoot As String
    Dim candidatePath As String

    addinRoot = GetAddinRoot()
    If LenB(addinRoot) = 0 Then
        Exit Function
    End If

    candidatePath = BuildPath(addinRoot, relativePath)
    If FileExists(candidatePath) Then
        FindBundledFile = candidatePath
    End If
End Function

Private Function GetBinaryRoot() As String
    GetBinaryRoot = BuildPath(GetRuntimeRoot, "bin")
End Function

Private Function GetWebRuntimeRoot() As String
    GetWebRuntimeRoot = BuildPath(GetRuntimeRoot, "web")
End Function

Private Function GetModelsRoot() As String
    GetModelsRoot = BuildPath(GetRuntimeRoot, "models")
End Function

Private Function GetPsRoot() As String
    GetPsRoot = BuildPath(GetRuntimeRoot, "ps1")
End Function

Private Function GetUserDataRoot() As String
    GetUserDataRoot = BuildPath(GetRuntimeRoot, "userdata")
End Function

Private Function GetWebViewUserDataRoot() As String
    GetWebViewUserDataRoot = BuildPath(GetUserDataRoot, "webview2")
End Function

Private Function BuildPath(ByVal leftPart As String, ByVal rightPart As String) As String
    If LenB(leftPart) = 0 Then
        BuildPath = rightPart
    ElseIf Right$(leftPart, 1) = "\" Then
        BuildPath = leftPart & rightPart
    Else
        BuildPath = leftPart & "\" & rightPart
    End If
End Function

Private Function GetParentFolder(ByVal fullPath As String) As String
    Dim fileSystem As Object

    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    GetParentFolder = fileSystem.GetParentFolderName(fullPath)
End Function

Private Sub EnsureFolder(ByVal folderPath As String)
    Dim fileSystem As Object
    Dim parentFolder As String

    If LenB(folderPath) = 0 Then
        Exit Sub
    End If

    If FolderExists(folderPath) Then
        Exit Sub
    End If

    parentFolder = GetParentFolder(folderPath)
    If LenB(parentFolder) > 0 Then
        If StrComp(parentFolder, folderPath, vbTextCompare) <> 0 Then
            EnsureFolder parentFolder
        End If
    End If

    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    If Not fileSystem.FolderExists(folderPath) Then
        fileSystem.CreateFolder folderPath
    End If
End Sub

Private Function FolderExists(ByVal folderPath As String) As Boolean
    Dim fileSystem As Object

    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    FolderExists = fileSystem.FolderExists(folderPath)
End Function

Private Function FileExists(ByVal filePath As String) As Boolean
    Dim fileSystem As Object

    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    FileExists = fileSystem.FileExists(filePath)
End Function

Private Sub DeleteFileIfExists(ByVal filePath As String)
    Dim fileSystem As Object

    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    If fileSystem.FileExists(filePath) Then
        fileSystem.DeleteFile filePath, True
    End If
End Sub

Private Sub CopyFileOverwrite(ByVal sourcePath As String, ByVal targetPath As String)
    Dim fileSystem As Object

    If Not FileExists(sourcePath) Then
        Err.Raise vbObjectError + 807, "LLMBridge.CopyFileOverwrite", "Required file was not found: " & sourcePath
    End If

    EnsureFolder GetParentFolder(targetPath)
    Set fileSystem = CreateObject("Scripting.FileSystemObject")
    fileSystem.CopyFile sourcePath, targetPath, True
End Sub

Private Sub WriteUtf8TextFile(ByVal targetPath As String, ByVal text As String)
    Dim stream As Object

    EnsureFolder GetParentFolder(targetPath)
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.WriteText text
    stream.SaveToFile targetPath, 2
    stream.Close
End Sub

Private Function ReadUtf8TextFileIfExists(ByVal targetPath As String) As String
    Dim stream As Object

    If Not FileExists(targetPath) Then
        ReadUtf8TextFileIfExists = vbNullString
        Exit Function
    End If

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2
    stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile targetPath
    ReadUtf8TextFileIfExists = stream.ReadText
    stream.Close
End Function

Private Function Utf8StringFromBytes(ByVal bytes As Variant) As String
    Dim stream As Object

    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.Write bytes
    stream.Position = 0
    stream.Type = 2
    stream.Charset = "utf-8"
    Utf8StringFromBytes = stream.ReadText
    stream.Close
End Function

Private Function Utf8BytesFromString(ByVal text As String) As Variant
    Dim textStream As Object
    Dim binaryStream As Object

    Set textStream = CreateObject("ADODB.Stream")
    textStream.Type = 2
    textStream.Charset = "utf-8"
    textStream.Open
    textStream.WriteText text
    textStream.Position = 0

    Set binaryStream = CreateObject("ADODB.Stream")
    binaryStream.Type = 1
    binaryStream.Open

    textStream.Position = 3
    textStream.CopyTo binaryStream
    binaryStream.Position = 0
    Utf8BytesFromString = binaryStream.Read

    binaryStream.Close
    textStream.Close
End Function

Private Function ByteArrayLength(ByRef bytes As Variant) As Long
    On Error GoTo EH
    ByteArrayLength = UBound(bytes) - LBound(bytes) + 1
    Exit Function

EH:
    ByteArrayLength = 0
End Function

Private Function BytesToHexString(ByRef bytes() As Byte) As String
    Dim index As Long
    Dim hexText As String

    For index = LBound(bytes) To UBound(bytes)
        hexText = hexText & Right$("0" & Hex$(bytes(index)), 2)
    Next index

    BytesToHexString = LCase$(hexText)
End Function

Private Function JsonEscape(ByVal text As String) As String
    Dim escaped As String

    escaped = text
    escaped = Replace(escaped, "\", "\\")
    escaped = Replace(escaped, Chr$(34), "\" & Chr$(34))
    escaped = Replace(escaped, "/", "\/")
    escaped = Replace(escaped, vbCrLf, "\n")
    escaped = Replace(escaped, vbCr, "\n")
    escaped = Replace(escaped, vbLf, "\n")
    escaped = Replace(escaped, vbTab, "\t")

    JsonEscape = escaped
End Function

Private Function Quote(ByVal text As String) As String
    Quote = """" & text & """"
End Function

Private Function ElapsedSeconds(ByVal startedAt As Double) As Double
    If Timer >= startedAt Then
        ElapsedSeconds = Timer - startedAt
    Else
        ElapsedSeconds = (86400# - startedAt) + Timer
    End If
End Function

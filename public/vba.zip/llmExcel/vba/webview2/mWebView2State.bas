Attribute VB_Name = "mWebView2State"
Option Explicit

Public gActiveHost As BridgeWebViewHost
Public gTargetHwnd As LongPtr
Public gHostWidthPx As Long
Public gHostHeightPx As Long

Public Sub SetActiveHost(ByVal host As BridgeWebViewHost)
    Set gActiveHost = host
End Sub

Public Sub ClearActiveHost()
    Set gActiveHost = Nothing
    gTargetHwnd = 0
    gHostWidthPx = 0
    gHostHeightPx = 0
End Sub

Attribute VB_Name = "mWebView2Helpers"
Option Explicit

Public Function PtrToStrW(ByVal wideStringPointer As LongPtr) As String
    Dim characterCount As Long
    Dim buffer As String

    If wideStringPointer = 0 Then
        PtrToStrW = vbNullString
        Exit Function
    End If

    characterCount = lstrlenW(wideStringPointer)
    If characterCount <= 0 Then
        PtrToStrW = vbNullString
        Exit Function
    End If

    buffer = String$(characterCount, vbNullChar)
    CopyMemory ByVal StrPtr(buffer), ByVal wideStringPointer, CLng(characterCount) * 2
    PtrToStrW = buffer
End Function

Public Function DcfGetString(ByVal instancePointer As LongPtr, ByVal vtblIndex As Long, ByVal memberName As String) As String
    Dim resultPointer As LongPtr
    Dim args(0) As Variant
    Dim argTypes(0) As Integer
    Dim argPtrs(0) As LongPtr
    Dim hr As Long
    Dim result As Variant

    args(0) = VarPtr(resultPointer)
    argTypes(0) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))

    hr = DispCallFunc(instancePointer, vtblIndex * LenB(instancePointer), CC_STDCALL, vbLong, 1, argTypes(0), argPtrs(0), result)
    If hr <> S_OK Then
        Debug.Print memberName & " failed before COM call completed. HRESULT=" & Hex$(hr)
        Exit Function
    End If

    If CLng(result) <> S_OK Then
        Debug.Print memberName & " returned HRESULT=" & Hex$(CLng(result))
        Exit Function
    End If

    If resultPointer <> 0 Then
        DcfGetString = PtrToStrW(resultPointer)
        CoTaskMemFree resultPointer
    End If
End Function

Public Function DcfCallStringArg(ByVal instancePointer As LongPtr, ByVal vtblIndex As Long, ByVal memberName As String, ByVal text As String) As Long
    Dim args(0) As Variant
    Dim argTypes(0) As Integer
    Dim argPtrs(0) As LongPtr
    Dim hr As Long
    Dim result As Variant

    args(0) = StrPtr(text)
    argTypes(0) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))

    hr = DispCallFunc(instancePointer, vtblIndex * LenB(instancePointer), CC_STDCALL, vbLong, 1, argTypes(0), argPtrs(0), result)
    If hr <> S_OK Then
        Debug.Print memberName & " failed before COM call completed. HRESULT=" & Hex$(hr)
        DcfCallStringArg = hr
        Exit Function
    End If

    DcfCallStringArg = CLng(result)
    If DcfCallStringArg <> S_OK Then
        Debug.Print memberName & " returned HRESULT=" & Hex$(DcfCallStringArg)
    End If
End Function

Public Function DcfCallStringAndObject(ByVal instancePointer As LongPtr, ByVal vtblIndex As Long, ByVal memberName As String, ByVal text As String, ByVal instance As Object) As Long
    Dim objectVariant As Variant
    Dim args(1) As Variant
    Dim argTypes(1) As Integer
    Dim argPtrs(1) As LongPtr
    Dim hr As Long
    Dim result As Variant

    Set objectVariant = instance

    args(0) = StrPtr(text)
    args(1) = VarPtr(objectVariant)
    argTypes(0) = vbLongPtr
    argTypes(1) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))
    argPtrs(1) = VarPtr(args(1))

    hr = DispCallFunc(instancePointer, vtblIndex * LenB(instancePointer), CC_STDCALL, vbLong, 2, argTypes(0), argPtrs(0), result)
    If hr <> S_OK Then
        Debug.Print memberName & " failed before COM call completed. HRESULT=" & Hex$(hr)
        DcfCallStringAndObject = hr
        Exit Function
    End If

    DcfCallStringAndObject = CLng(result)
    If DcfCallStringAndObject <> S_OK Then
        Debug.Print memberName & " returned HRESULT=" & Hex$(DcfCallStringAndObject)
    End If
End Function

Public Function DcfRegisterHandler(ByVal browser As WebView2, ByVal vtblIndex As Long, ByVal memberName As String, ByVal callbackAddress As LongPtr, Optional ByVal handlerName As String = vbNullString) As Long
    Dim handler As WebView2Handler
    Dim args(1) As Variant
    Dim argTypes(1) As Integer
    Dim argPtrs(1) As LongPtr
    Dim token As LongPtr
    Dim hr As Long
    Dim result As Variant

    Set handler = New WebView2Handler
    handler.CreateVTable callbackAddress, browser.ppWebView2, handlerName
    browser.HandlerCollection.Add handler

    args(0) = handler.Pointer
    args(1) = VarPtr(token)
    argTypes(0) = vbLongPtr
    argTypes(1) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))
    argPtrs(1) = VarPtr(args(1))

    hr = DispCallFunc(browser.ppWebView2, vtblIndex * LenB(browser.ppWebView2), CC_STDCALL, vbLong, 2, argTypes(0), argPtrs(0), result)
    If hr <> S_OK Then
        Debug.Print memberName & " failed before COM call completed. HRESULT=" & Hex$(hr)
        DcfRegisterHandler = hr
        Exit Function
    End If

    DcfRegisterHandler = CLng(result)
    If DcfRegisterHandler = S_OK Then
        handler.Token = token
        RegisterInstance handler.Pointer, browser
    Else
        Debug.Print memberName & " returned HRESULT=" & Hex$(DcfRegisterHandler)
    End If
End Function

Public Function DcfRegisterStringAndHandler(ByVal browser As WebView2, ByVal vtblIndex As Long, ByVal memberName As String, ByVal text As String, ByVal callbackAddress As LongPtr) As Long
    Dim handler As WebView2Handler
    Dim args(1) As Variant
    Dim argTypes(1) As Integer
    Dim argPtrs(1) As LongPtr
    Dim hr As Long
    Dim result As Variant

    Set handler = New WebView2Handler
    handler.CreateVTable callbackAddress, browser.ppWebView2, memberName
    browser.HandlerCollection.Add handler
    RegisterInstance handler.Pointer, browser

    args(0) = StrPtr(text)
    args(1) = handler.Pointer
    argTypes(0) = vbLongPtr
    argTypes(1) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))
    argPtrs(1) = VarPtr(args(1))

    hr = DispCallFunc(browser.ppWebView2, vtblIndex * LenB(browser.ppWebView2), CC_STDCALL, vbLong, 2, argTypes(0), argPtrs(0), result)
    If hr <> S_OK Then
        Debug.Print memberName & " failed before COM call completed. HRESULT=" & Hex$(hr)
        UnregisterInstance handler.Pointer
        DcfRegisterStringAndHandler = hr
        Exit Function
    End If

    DcfRegisterStringAndHandler = CLng(result)
    If DcfRegisterStringAndHandler <> S_OK Then
        Debug.Print memberName & " returned HRESULT=" & Hex$(DcfRegisterStringAndHandler)
        UnregisterInstance handler.Pointer
    End If
End Function

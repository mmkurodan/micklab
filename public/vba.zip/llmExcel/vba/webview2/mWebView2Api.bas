Attribute VB_Name = "mWebView2Api"
Option Explicit

Public Declare PtrSafe Function CreateCoreWebView2EnvironmentWithOptions Lib "WebView2Loader.dll" ( _
    ByVal browserExecutableFolder As LongPtr, _
    ByVal userDataFolder As LongPtr, _
    ByVal environmentOptions As LongPtr, _
    ByVal environmentCreatedHandler As LongPtr) As Long

Public Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As LongPtr)
Public Declare PtrSafe Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As LongPtr)
Public Declare PtrSafe Function GlobalAlloc Lib "kernel32" (ByVal uFlags As Long, ByVal dwBytes As LongPtr) As LongPtr
Public Declare PtrSafe Function GlobalFree Lib "kernel32" (ByVal hMem As LongPtr) As LongPtr
Public Declare PtrSafe Sub CoTaskMemFree Lib "ole32.dll" (ByVal pv As LongPtr)
Public Declare PtrSafe Function lstrlenW Lib "kernel32" (ByVal lpString As LongPtr) As Long

Public Declare PtrSafe Function DispCallFunc Lib "oleaut32.dll" ( _
    ByVal pvInstance As LongPtr, _
    ByVal oVft As LongPtr, _
    ByVal cc As Long, _
    ByVal vtReturn As Integer, _
    ByVal cArgs As Long, _
    ByRef rgvt As Integer, _
    ByRef rgpvarg As LongPtr, _
    ByRef pvargResult As Variant) As Long

Public Declare PtrSafe Function MoveWindow Lib "user32" ( _
    ByVal hwnd As LongPtr, _
    ByVal x As Long, _
    ByVal y As Long, _
    ByVal nWidth As Long, _
    ByVal nHeight As Long, _
    ByVal bRepaint As Long) As Long

Public Declare PtrSafe Function FindWindowEx Lib "user32" Alias "FindWindowExA" ( _
    ByVal hWndParent As LongPtr, _
    ByVal hWndChildAfter As LongPtr, _
    ByVal lpszClass As String, _
    ByVal lpszWindow As String) As LongPtr

Public Declare PtrSafe Function CreateWindowExW Lib "user32" ( _
    ByVal dwExStyle As Long, _
    ByVal lpClassName As LongPtr, _
    ByVal lpWindowName As LongPtr, _
    ByVal dwStyle As Long, _
    ByVal X As Long, _
    ByVal Y As Long, _
    ByVal nWidth As Long, _
    ByVal nHeight As Long, _
    ByVal hWndParent As LongPtr, _
    ByVal hMenu As LongPtr, _
    ByVal hInstance As LongPtr, _
    ByVal lpParam As LongPtr) As LongPtr

Public Declare PtrSafe Function DestroyWindow Lib "user32" (ByVal hwnd As LongPtr) As Long
Public Declare PtrSafe Function ShowWindow Lib "user32" (ByVal hwnd As LongPtr, ByVal nCmdShow As Long) As Long

Public Const GPTR As Long = &H40
Public Const S_OK As Long = 0
Public Const CC_STDCALL As Long = 4
Public Const WS_EX_TOOLWINDOW As Long = &H80
Public Const WS_POPUP As Long = &H80000000
Public Const WS_VISIBLE As Long = &H10000000
Public Const SW_SHOWNOACTIVATE As Long = 4

#If Win64 Then
    Public Const vbLongPtr = vbLongLong
#Else
    Public Const vbLongPtr = vbLong
#End If

Public Function CallCreateController(ByVal pEnvironment As LongPtr, ByVal hostHwnd As LongPtr, ByVal pHandler As LongPtr) As Long
    Dim args(1) As Variant
    Dim argTypes(1) As Integer
    Dim argPtrs(1) As LongPtr
    Dim result As Variant

    args(0) = hostHwnd
    args(1) = pHandler
    argTypes(0) = vbLongPtr
    argTypes(1) = vbLongPtr
    argPtrs(0) = VarPtr(args(0))
    argPtrs(1) = VarPtr(args(1))

    CallCreateController = DispCallFunc(pEnvironment, 3 * LenB(pEnvironment), CC_STDCALL, vbLong, 2, argTypes(0), argPtrs(0), result)
End Function

Public Function CallAddRef(ByVal pUnknown As LongPtr) As Long
    Dim result As Variant
    CallAddRef = DispCallFunc(pUnknown, 1 * LenB(pUnknown), CC_STDCALL, vbLong, 0, 0, 0, result)
End Function

Public Function CreateHiddenHostWindow(ByVal widthPx As Long, ByVal heightPx As Long) As LongPtr
    Dim hwnd As LongPtr

    hwnd = CreateWindowExW(WS_EX_TOOLWINDOW, StrPtr("Static"), StrPtr("LLMExcelWebView2Host"), _
        WS_POPUP Or WS_VISIBLE, -32000, -32000, widthPx, heightPx, 0, 0, 0, 0)
    If hwnd = 0 Then
        Err.Raise vbObjectError + 910, "mWebView2Api.CreateHiddenHostWindow", "Failed to create a hidden WebView2 host window."
    End If

    Call MoveWindow(hwnd, -32000, -32000, widthPx, heightPx, 1)
    Call ShowWindow(hwnd, SW_SHOWNOACTIVATE)
    CreateHiddenHostWindow = hwnd
End Function

Public Sub DestroyHiddenHostWindow(ByVal hwnd As LongPtr)
    If hwnd <> 0 Then
        Call DestroyWindow(hwnd)
    End If
End Sub

Public Sub ResizeWebView2Force(ByVal parentHwnd As LongPtr, ByVal widthPx As Long, ByVal heightPx As Long)
    Dim child0 As LongPtr
    Dim child1 As LongPtr
    Dim childD3D As LongPtr

    If parentHwnd = 0 Then
        Exit Sub
    End If

    Call MoveWindow(parentHwnd, -32000, -32000, widthPx, heightPx, 1)

    child0 = FindWindowEx(parentHwnd, 0, "Chrome_WidgetWin_0", vbNullString)
    If child0 = 0 Then
        Exit Sub
    End If

    Call MoveWindow(child0, 0, 0, widthPx, heightPx, 1)

    child1 = FindWindowEx(child0, 0, "Chrome_WidgetWin_1", vbNullString)
    If child1 <> 0 Then
        Call MoveWindow(child1, 0, 0, widthPx, heightPx, 1)
        childD3D = FindWindowEx(child1, 0, "Intermediate D3D Window", vbNullString)
        If childD3D <> 0 Then
            Call MoveWindow(childD3D, 0, 0, widthPx, heightPx, 1)
        End If
    End If
End Sub

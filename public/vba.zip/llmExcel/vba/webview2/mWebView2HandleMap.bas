Attribute VB_Name = "mWebView2HandleMap"
Option Explicit

Public gInstanceMap As Object

Public Sub RegisterInstance(ByVal handlerPointer As LongPtr, ByVal instance As Object)
    If gInstanceMap Is Nothing Then
        Set gInstanceMap = CreateObject("Scripting.Dictionary")
    End If

    If gInstanceMap.Exists(CStr(handlerPointer)) Then
        gInstanceMap.Remove CStr(handlerPointer)
    End If

    gInstanceMap.Add CStr(handlerPointer), instance
End Sub

Public Sub UnregisterInstance(ByVal handlerPointer As LongPtr)
    If gInstanceMap Is Nothing Then
        Exit Sub
    End If

    If gInstanceMap.Exists(CStr(handlerPointer)) Then
        gInstanceMap.Remove CStr(handlerPointer)
    End If
End Sub

Public Function GetInstance(ByVal handlerPointer As LongPtr) As Object
    If gInstanceMap Is Nothing Then
        Exit Function
    End If

    If gInstanceMap.Exists(CStr(handlerPointer)) Then
        Set GetInstance = gInstanceMap.Item(CStr(handlerPointer))
    End If
End Function

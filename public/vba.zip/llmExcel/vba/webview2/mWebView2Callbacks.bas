Attribute VB_Name = "mWebView2Callbacks"
Option Explicit

Public Function GetAddr(ByVal addr As LongPtr) As LongPtr
    GetAddr = addr
End Function

Public Function Handler_QueryInterface(ByVal thisPointer As LongPtr, ByVal riid As LongPtr, ByRef ppvObject As LongPtr) As Long
    ppvObject = thisPointer
    Handler_QueryInterface = S_OK
End Function

Public Function Handler_AddRef(ByVal thisPointer As LongPtr) As Long
    Handler_AddRef = 1
End Function

Public Function Handler_Release(ByVal thisPointer As LongPtr) As Long
    Handler_Release = 1
End Function

Public Function Handler_Invoke(ByVal thisPointer As LongPtr, ByVal errorCode As Long, ByVal environmentPointer As LongPtr) As Long
    On Error Resume Next
    If Not gActiveHost Is Nothing Then
        gActiveHost.OnEnvironmentCreated errorCode, environmentPointer
    End If
    Handler_Invoke = S_OK
End Function

Public Function ControllerHandler_Invoke(ByVal thisPointer As LongPtr, ByVal errorCode As Long, ByVal controllerPointer As LongPtr) As Long
    On Error Resume Next
    If Not gActiveHost Is Nothing Then
        gActiveHost.OnControllerCreated errorCode, controllerPointer
    End If
    ControllerHandler_Invoke = S_OK
End Function

Public Function NavCompleted_Invoke(ByVal thisPointer As LongPtr, ByVal sender As LongPtr, ByVal args As LongPtr) As Long
    On Error Resume Next

    Dim target As WebView2
    Set target = GetInstance(thisPointer)
    If Not target Is Nothing Then
        target.NotifyNavigationCompleted
    Else
        UnregisterInstance thisPointer
    End If

    NavCompleted_Invoke = S_OK
End Function

Public Function ExecuteScript_Invoke(ByVal thisPointer As LongPtr, ByVal errorCode As Long, ByVal resultJsonPointer As LongPtr) As Long
    On Error Resume Next

    Dim target As WebView2
    Set target = GetInstance(thisPointer)
    If Not target Is Nothing Then
        If errorCode = S_OK Then
            target.NotifyExecuteScriptCompleted PtrToStrW(resultJsonPointer)
        Else
            target.NotifyExecuteScriptFailed "ExecuteScript failed. HRESULT=" & Hex$(errorCode)
        End If
    End If

    UnregisterInstance thisPointer
    ExecuteScript_Invoke = S_OK
End Function

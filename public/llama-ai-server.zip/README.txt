llama-ai-server (Windows)
=========================

Single-file local LLM server (llama.cpp) with Ollama- and OpenAI-compatible
HTTP APIs, an embedded WebUI, embeddings, tokenizer, structured output and
multimodal (vision/audio) support. No installer, no extra DLLs.

Two builds are included — pick one:

  llama-ai-server.exe        GPU build (Vulkan) + CPU fallback.
                             Runs on the GPU when available (NVIDIA / Intel /
                             AMD via the Vulkan driver) and falls back to CPU
                             otherwise. Needs vulkan-1.dll, which ships with
                             every modern Windows GPU driver. Recommended.

  llama-ai-server-cpu.exe    CPU-only build. Smaller and runs anywhere; no GPU
                             acceleration. Use this if the GPU build won't start
                             (very old system / no Vulkan driver).

Quick start
-----------
  llama-ai-server.exe --model <path-to-model.gguf>

The backend is chosen automatically (profile field backendType = 2, "auto"):

  - a discrete GPU is used when present, offloading as many layers as fit its
    free memory (gpuOffloadLayers = 0);
  - an integrated GPU is used only if it is faster than the CPU. This is
    measured once, the first time a model is loaded (a few extra seconds), and
    logged as "init: integrated GPU X tok/s vs CPU Y tok/s";
  - otherwise, or if the GPU fails to load the model, the CPU is used.

Add --gpu or --cpu to force one for every profile. Profiles saved by an older
version with the CPU backend are switched to auto once, on first start; set
backendType back to 0 in the Profiles editor to keep one on the CPU.

Then open http://127.0.0.1:11434/ in a browser for the WebUI.
Use the "Profiles" link in the sidebar to manage model profiles (context size,
nPredict, KV-cache quantization, flash attention, GPU offload, sampling, etc.).

Run with --help for all options.

Reasoning / thinking models
---------------------------
Thinking is on by default and can be switched off per profile (the
"enableThinking" checkbox in the Profiles editor) or per request:

  OpenAI    {"enable_thinking": false}
            {"chat_template_kwargs": {"enable_thinking": false}}
  Ollama    {"think": false}

Whether a model can actually be told not to think depends on its chat template;
GET /props reports chat_template_caps.supports_enable_thinking. When a template
ignores the flag, the model still reasons, but the reasoning is always kept out
of the answer.

The chain of thought is returned separately, never mixed into the answer text:
OpenAI uses reasoning_content (streaming: delta.reasoning_content) and Ollama
uses message.thinking. Send {"reasoning_format": "none"} to switch that off and
receive the raw <think> block inline instead.

Structured output
-----------------
  OpenAI    {"response_format": {"type": "json_schema",
                                 "json_schema": {"schema": { ... }}}}
            {"response_format": {"type": "json_object"}}
  Ollama    {"format": "json"} or {"format": { ...JSON schema... }}
  Both      {"grammar": "<GBNF>"}

A JSON schema is applied through the chat template, so it works together with
thinking: the model reasons first and only the answer is constrained. A raw
GBNF grammar constrains the whole output from the first token and therefore
cannot be combined with thinking — send enable_thinking:false with it, or use a
JSON schema instead.

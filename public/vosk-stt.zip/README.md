# vosk-stt — 常時文字起こし + 期間指定取得API (単一exe)

Vosk の日本語モデルで PC の音声を常時テキスト化し、タイムスタンプ付きで記録、
HTTP API で「指定した期間のテキスト」を取り出せる単一 exe です。

- 配布物は `dist\vosk-stt.exe` **1ファイルのみ**
- モデルは**初回起動時に自動ダウンロード**（`%LOCALAPPDATA%\vosk-stt\models` にキャッシュ）
- `--model small|full` で軽量モデルと通常（高精度）モデルを実行時に切り替え
- `--source mic|system|both` で**マイク**と**PCの再生音（Teams / Zoom の相手の声など）**を選択
- API の既定ポートは **47653**（他サービスと衝突しにくい未割り当て番号）

## 使い方

```
vosk-stt.exe                        # マイク + small モデル
vosk-stt.exe --model full           # 通常（高精度）モデル
vosk-stt.exe --source system        # PCの再生音だけを文字起こし
vosk-stt.exe --source both          # マイク + 再生音（会議全体を残す場合）
vosk-stt.exe --list-devices         # 入力/ループバックデバイス一覧
vosk-stt.exe --model full --download-only   # モデルの事前取得のみ
```

Ctrl+C で終了します。主なオプション:

| オプション | 既定 | 内容 |
|---|---|---|
| `--model {small,full}` | `small` | small=約48MB / full=約1GB（初回DL） |
| `--source {mic,system,both}` | `mic` | 取り込む音源 |
| `--port` | `47653` | API ポート |
| `--host` | `127.0.0.1` | `0.0.0.0` で LAN 公開 |
| `--log-dir` | exe と同じ場所の `transcripts\` | 記録の出力先 |
| `--model-dir` | `%LOCALAPPDATA%\vosk-stt\models` | モデルのキャッシュ先（環境変数 `VOSK_STT_MODEL_DIR` も可） |
| `--device` / `--system-device` | OS の既定 | マイク / 再生デバイスの指定（名前の一部か番号） |
| `--download-only` / `--no-download` | – | 事前取得のみ / 未取得ならエラー |
| `--no-api` / `--no-partial` / `--quiet` / `--verbose` | – | API 無効 / 途中表示抑制 / 静音 / APIログ |

## 記録ファイル

`transcripts\transcript-YYYY-MM-DD.txt` に 1 行 1 発話でタブ区切り追記されます。

```
2026-10-14T09:00:00+09:00	mic	おはよう ござい ます
2026-10-14T09:00:05+09:00	system	今日 の 会議 を 始め ます
```

API はこのファイルを読むため、**再起動後も過去の期間を取得できます**。

## API (既定 http://127.0.0.1:47653)

| エンドポイント | 内容 |
|---|---|
| `GET /text?minutes=10` | 直近10分（JSON: `from`, `to`, `count`, `records[]`, `text`） |
| `GET /text?from=2026-10-14T09:00:00&to=2026-10-14T10:00:00` | 期間指定 |
| `GET /text?from=-1h` | 相対指定（1時間前〜現在）。`now` も使用可 |
| `GET /text?date=2026-10-14` | 日付指定（その日全体） |
| `GET /text?minutes=10&source=system` | 音源で絞り込み（`mic` / `system` / カンマ区切り） |
| `GET /text?minutes=10&format=text` | `時刻<TAB>音源<TAB>本文` のプレーンテキスト（`/text.txt` も同じ） |
| `GET /text?minutes=10&format=raw` | 本文のみ |
| `GET /status` | モデル・音源ごとの稼働状況・記録件数・ログ出力先 |
| `GET /partial` | 認識途中の文字列（音源別） |
| `GET /days` | 記録のある日付一覧 |
| `GET /health` | 死活監視（全音源稼働で `ok`、一部停止で `degraded`+503） |

時刻は ISO8601 / `YYYY-MM-DD HH:MM:SS` / epoch 秒・ミリ秒 / `-10m` / `now` を受け付け、
`seconds` `minutes` `hours` `days` と `limit`（末尾 N 件）も指定できます。

```powershell
curl "http://127.0.0.1:47653/text?minutes=10"
curl "http://127.0.0.1:47653/text?from=-30m&source=system&format=text"
```

## システム音声（Teams / Zoom）について

相手側の声は PC の再生音として流れるため、Windows の **WASAPI ループバック**で
既定の再生デバイスから取り込みます（ステレオミキサーの有効化は不要）。
自分の声はマイク側で拾うので、会議全体を残すなら `--source both` を指定してください。
再生デバイスを切り替えた場合は再起動すると新しい既定デバイスを拾います。

## ビルド（開発時）

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1   # -> dist\vosk-stt.exe (約23MB)
```

Python 3.11 と `requirements.txt`（`vosk`, `PyAudioWPatch`, `pyinstaller`）を使用します。
音声入力に `PyAudioWPatch` を使うのは、同梱 PortAudio が WASAPI ループバックに
対応している唯一の選択肢だったためです（`sounddevice` の PortAudio 19.7.0-devel は非対応）。
